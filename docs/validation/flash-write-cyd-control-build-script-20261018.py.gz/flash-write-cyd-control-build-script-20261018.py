"""Build a scoped Xtensa baseline while preserving the tested installed binaries."""
from pathlib import Path
import hashlib,json,os,subprocess

root=Path('C:/Work/QEMU-ESP32/.worktree/flash-write-audit')
p=root/'hw/block/m25p80.c'
current=p.read_bytes()
baseline=subprocess.check_output(['git','show','aab05d5de6:hw/block/m25p80.c'],cwd=root)
control=root/'bin/qemu-system-xtensa-pre-flash-control.exe'
installed=root/'bin/qemu-system-xtensa.exe'
sha=lambda b:hashlib.sha256(b).hexdigest()
installed_sha=sha(installed.read_bytes())
env=dict(os.environ,CHERE_INVOKING='1',MSYSTEM='MINGW64')
command=['C:/Work/HLV-codec/local_tools/msys2/msys64/usr/bin/bash.exe','-lc',
         'cd /c/Work/QEMU-ESP32/.worktree/flash-write-audit/build-esp32c2 && ninja -j6 qemu-system-xtensa.exe']
record=dict(base_commit='aab05d5de6fc9c6b0a784221d6629581a887679b',
    scope='Same compiler/configuration and classic machine sources; only m25p80.c replaced by its exact pre-change Git blob. C2/C3 cache changes are unused by this Xtensa machine.',
    old_flash_source_sha256=sha(baseline),fixed_flash_source_sha256=sha(current),installed_sha256=installed_sha)
try:
    p.write_bytes(baseline)
    subprocess.run(command,cwd=root,env=env,check=True)
    control.write_bytes((root/'build-esp32c2/qemu-system-xtensa.exe').read_bytes())
    record['control_executable_sha256']=sha(control.read_bytes())
finally:
    p.write_bytes(current)
    assert sha(p.read_bytes())==record['fixed_flash_source_sha256']
    assert sha(installed.read_bytes())==installed_sha
    subprocess.run(command,cwd=root,env=env,check=True)
Path('C:/Work/yoRadio/.build/flash-audit-xtensa-control-build-20261018.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
