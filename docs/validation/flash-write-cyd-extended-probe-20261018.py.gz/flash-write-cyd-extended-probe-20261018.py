from pathlib import Path
import json,sys
sys.path.insert(0,'C:/Work/QEMU-ESP32/.worktree/flash-write-audit/tools')
import test_esp_legacy as legacy
root=Path('C:/Work/QEMU-ESP32/.worktree/flash-write-audit')
out=Path('C:/Work/yoRadio/.build/flash-audit-cyd-extended-v2-20261018')
original=legacy.QMP

class Observer(original):
    def execute(self,command,**kwargs):
        if command=='screendump':
            registers=super().execute('human-monitor-command',**{'command-line':'info registers'})
            (out/'registers.txt').write_text(registers)
        return super().execute(command,**kwargs)

legacy.QMP=Observer
report=legacy.run_guest(root/'bin/qemu-system-xtensa.exe',
    Path('C:/Work/QEMU-ESP32/.cache/esp-boards/cyd-archive/manifest'),
    'esp32,st7789=on,sdspi=on',out,Path('C:/Work/QEMU-ESP32/pc-bios'),60)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
