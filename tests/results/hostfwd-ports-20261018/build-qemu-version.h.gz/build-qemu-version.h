#define QEMU_PKGVERSION "yoRadio host-forwarding control"
#define QEMU_FULL_VERSION "9.2.2 (yoRadio host-forwarding control)"
