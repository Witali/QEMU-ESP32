
build-esp32c2/subprojects/slirp-win32/libslirp.a.p/src_tcp_subr.c.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <tcp_init>:
       0:	48 8d 81 c0 01 00 00 	lea    0x1c0(%rcx),%rax
       7:	c7 81 78 03 00 00 01 	movl   $0x1,0x378(%rcx)
       e:	00 00 00 
      11:	48 89 81 c8 01 00 00 	mov    %rax,0x1c8(%rcx)
      18:	48 89 81 c0 01 00 00 	mov    %rax,0x1c0(%rcx)
      1f:	48 89 81 70 03 00 00 	mov    %rax,0x370(%rcx)
      26:	31 c0                	xor    %eax,%eax
      28:	31 c9                	xor    %ecx,%ecx
      2a:	c3                   	ret
      2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000000030 <tcp_template>:
      30:	56                   	push   %rsi
      31:	53                   	push   %rbx
      32:	48 83 ec 38          	sub    $0x38,%rsp
      36:	66 0f ef c0          	pxor   %xmm0,%xmm0
      3a:	31 d2                	xor    %edx,%edx
      3c:	48 8b 71 70          	mov    0x70(%rcx),%rsi
      40:	48 c7 41 28 00 00 00 	movq   $0x0,0x28(%rcx)
      47:	00 
      48:	48 89 cb             	mov    %rcx,%rbx
      4b:	c7 41 50 00 00 00 00 	movl   $0x0,0x50(%rcx)
      52:	66 89 51 54          	mov    %dx,0x54(%rcx)
      56:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
      5a:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
      5e:	0f b7 46 50          	movzwl 0x50(%rsi),%eax
      62:	66 83 f8 02          	cmp    $0x2,%ax
      66:	74 68                	je     d0 <tcp_template+0xa0>
      68:	66 83 f8 17          	cmp    $0x17,%ax
      6c:	0f 85 91 00 00 00    	jne    103 <tcp_template+0xd3>
      72:	c6 41 51 06          	movb   $0x6,0x51(%rcx)
      76:	b9 14 00 00 00       	mov    $0x14,%ecx
      7b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 81 <tcp_template+0x51>
			7d: IMAGE_REL_AMD64_REL32	__imp_htons
      81:	66 89 43 56          	mov    %ax,0x56(%rbx)
      85:	f3 0f 6f 46 58       	movdqu 0x58(%rsi),%xmm0
      8a:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
      8e:	f3 0f 6f 86 d8 00 00 	movdqu 0xd8(%rsi),%xmm0
      95:	00 
      96:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
      9a:	0f b7 46 52          	movzwl 0x52(%rsi),%eax
      9e:	66 89 43 58          	mov    %ax,0x58(%rbx)
      a2:	0f b7 86 d2 00 00 00 	movzwl 0xd2(%rsi),%eax
      a9:	66 89 43 5a          	mov    %ax,0x5a(%rbx)
      ad:	48 c7 43 5c 00 00 00 	movq   $0x0,0x5c(%rbx)
      b4:	00 
      b5:	48 c7 43 64 50 00 00 	movq   $0x50,0x64(%rbx)
      bc:	00 
      bd:	48 83 c4 38          	add    $0x38,%rsp
      c1:	5b                   	pop    %rbx
      c2:	5e                   	pop    %rsi
      c3:	31 c0                	xor    %eax,%eax
      c5:	31 d2                	xor    %edx,%edx
      c7:	31 c9                	xor    %ecx,%ecx
      c9:	45 31 c0             	xor    %r8d,%r8d
      cc:	45 31 c9             	xor    %r9d,%r9d
      cf:	c3                   	ret
      d0:	c6 41 39 06          	movb   $0x6,0x39(%rcx)
      d4:	b9 14 00 00 00       	mov    $0x14,%ecx
      d9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # df <tcp_template+0xaf>
			db: IMAGE_REL_AMD64_REL32	__imp_htons
      df:	66 89 43 56          	mov    %ax,0x56(%rbx)
      e3:	8b 46 54             	mov    0x54(%rsi),%eax
      e6:	89 43 30             	mov    %eax,0x30(%rbx)
      e9:	8b 86 d4 00 00 00    	mov    0xd4(%rsi),%eax
      ef:	89 43 34             	mov    %eax,0x34(%rbx)
      f2:	0f b7 46 52          	movzwl 0x52(%rsi),%eax
      f6:	66 89 43 58          	mov    %ax,0x58(%rbx)
      fa:	0f b7 86 d2 00 00 00 	movzwl 0xd2(%rsi),%eax
     101:	eb a6                	jmp    a9 <tcp_template+0x79>
     103:	31 c0                	xor    %eax,%eax
     105:	4c 8d 0d 90 03 00 00 	lea    0x390(%rip),%r9        # 49c <tcp_respond+0x36c>
			108: IMAGE_REL_AMD64_REL32	.rdata
     10c:	41 b8 5b 00 00 00    	mov    $0x5b,%r8d
     112:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
     117:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 11e <tcp_template+0xee>
			11a: IMAGE_REL_AMD64_REL32	.rdata
     11e:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 14f <tcp_respond+0x1f>
			121: IMAGE_REL_AMD64_REL32	.rdata
     125:	e8 00 00 00 00       	call   12a <tcp_template+0xfa>
			126: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
     12a:	90                   	nop
     12b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000000130 <tcp_respond>:
     130:	41 57                	push   %r15
     132:	41 56                	push   %r14
     134:	41 55                	push   %r13
     136:	41 54                	push   %r12
     138:	55                   	push   %rbp
     139:	57                   	push   %rdi
     13a:	56                   	push   %rsi
     13b:	53                   	push   %rbx
     13c:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
     143:	48 8b 3d 00 00 00 00 	mov    0x0(%rip),%rdi        # 14a <tcp_respond+0x1a>
			146: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     14a:	44 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14d
     151:	00 
     152:	44 8b a4 24 08 01 00 	mov    0x108(%rsp),%r12d
     159:	00 
     15a:	0f b7 ac 24 10 01 00 	movzwl 0x110(%rsp),%ebp
     161:	00 
     162:	44 89 4c 24 34       	mov    %r9d,0x34(%rsp)
     167:	48 89 ce             	mov    %rcx,%rsi
     16a:	49 89 d5             	mov    %rdx,%r13
     16d:	4c 89 c3             	mov    %r8,%rbx
     170:	f6 07 01             	testb  $0x1,(%rdi)
     173:	0f 85 a7 02 00 00    	jne    420 <tcp_respond+0x2f0>
     179:	48 85 f6             	test   %rsi,%rsi
     17c:	0f 84 99 03 00 00    	je     51b <tcp_respond+0x3eb>
     182:	48 8b 46 70          	mov    0x70(%rsi),%rax
     186:	8b b8 74 01 00 00    	mov    0x174(%rax),%edi
     18c:	2b b8 70 01 00 00    	sub    0x170(%rax),%edi
     192:	89 7c 24 3c          	mov    %edi,0x3c(%rsp)
     196:	48 85 db             	test   %rbx,%rbx
     199:	0f 84 a1 01 00 00    	je     340 <tcp_respond+0x210>
     19f:	4c 89 6b 30          	mov    %r13,0x30(%rbx)
     1a3:	c7 43 38 44 00 00 00 	movl   $0x44,0x38(%rbx)
     1aa:	66 83 fd 02          	cmp    $0x2,%bp
     1ae:	0f 84 64 01 00 00    	je     318 <tcp_respond+0x1e8>
     1b4:	66 83 fd 17          	cmp    $0x17,%bp
     1b8:	0f 85 d3 03 00 00    	jne    591 <tcp_respond+0x461>
     1be:	f3 41 0f 6f 45 18    	movdqu 0x18(%r13),%xmm0
     1c4:	f3 41 0f 6f 4d 08    	movdqu 0x8(%r13),%xmm1
     1ca:	44 88 64 24 3b       	mov    %r12b,0x3b(%rsp)
     1cf:	41 0f 11 45 08       	movups %xmm0,0x8(%r13)
     1d4:	66 41 0f 6e 45 30    	movd   0x30(%r13),%xmm0
     1da:	41 0f 11 4d 18       	movups %xmm1,0x18(%r13)
     1df:	f2 0f 70 c0 e1       	pshuflw $0xe1,%xmm0,%xmm0
     1e4:	66 41 0f 7e 45 30    	movd   %xmm0,0x30(%r13)
     1ea:	b9 14 00 00 00       	mov    $0x14,%ecx
     1ef:	4c 8b 3d 00 00 00 00 	mov    0x0(%rip),%r15        # 1f6 <tcp_respond+0xc6>
			1f2: IMAGE_REL_AMD64_REL32	__imp_htons
     1f6:	41 ff d7             	call   *%r15
     1f9:	31 d2                	xor    %edx,%edx
     1fb:	44 89 f1             	mov    %r14d,%ecx
     1fe:	4c 8b 35 00 00 00 00 	mov    0x0(%rip),%r14        # 205 <tcp_respond+0xd5>
			201: IMAGE_REL_AMD64_REL32	__imp_htonl
     205:	66 41 89 45 2e       	mov    %ax,0x2e(%r13)
     20a:	c7 43 38 44 00 00 00 	movl   $0x44,0x38(%rbx)
     211:	66 41 89 55 2c       	mov    %dx,0x2c(%r13)
     216:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
     21d:	00 
     21e:	41 ff d6             	call   *%r14
     221:	8b 4c 24 34          	mov    0x34(%rsp),%ecx
     225:	41 89 45 34          	mov    %eax,0x34(%r13)
     229:	41 ff d6             	call   *%r14
     22c:	41 c6 45 3c 50       	movb   $0x50,0x3c(%r13)
     231:	41 89 45 38          	mov    %eax,0x38(%r13)
     235:	0f b6 44 24 3b       	movzbl 0x3b(%rsp),%eax
     23a:	41 88 45 3d          	mov    %al,0x3d(%r13)
     23e:	48 85 f6             	test   %rsi,%rsi
     241:	0f 84 e9 02 00 00    	je     530 <tcp_respond+0x400>
     247:	0f b6 8e cd 00 00 00 	movzbl 0xcd(%rsi),%ecx
     24e:	8b 44 24 3c          	mov    0x3c(%rsp),%eax
     252:	d3 f8                	sar    %cl,%eax
     254:	0f b7 c8             	movzwl %ax,%ecx
     257:	41 ff d7             	call   *%r15
     25a:	66 41 89 45 3e       	mov    %ax,0x3e(%r13)
     25f:	ba 44 00 00 00       	mov    $0x44,%edx
     264:	48 89 d9             	mov    %rbx,%rcx
     267:	41 c7 45 40 00 00 00 	movl   $0x0,0x40(%r13)
     26e:	00 
     26f:	e8 00 00 00 00       	call   274 <tcp_respond+0x144>
			270: IMAGE_REL_AMD64_REL32	cksum
     274:	66 41 89 45 40       	mov    %ax,0x40(%r13)
     279:	48 8b 43 30          	mov    0x30(%rbx),%rax
     27d:	f3 0f 6f 00          	movdqu (%rax),%xmm0
     281:	8b 50 40             	mov    0x40(%rax),%edx
     284:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
     289:	f3 0f 6f 40 10       	movdqu 0x10(%rax),%xmm0
     28e:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
     295:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
     29a:	f3 0f 6f 40 20       	movdqu 0x20(%rax),%xmm0
     29f:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
     2a4:	f3 0f 6f 40 30       	movdqu 0x30(%rax),%xmm0
     2a9:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     2ae:	66 83 fd 02          	cmp    $0x2,%bp
     2b2:	0f 84 08 01 00 00    	je     3c0 <tcp_respond+0x290>
     2b8:	66 83 fd 17          	cmp    $0x17,%bp
     2bc:	0f 85 a8 02 00 00    	jne    56a <tcp_respond+0x43a>
     2c2:	0f b6 50 29          	movzbl 0x29(%rax),%edx
     2c6:	0f b7 48 2e          	movzwl 0x2e(%rax),%ecx
     2ca:	4c 8d 40 08          	lea    0x8(%rax),%r8
     2ce:	83 6b 38 08          	subl   $0x8,0x38(%rbx)
     2d2:	f3 0f 6f 44 24 58    	movdqu 0x58(%rsp),%xmm0
     2d8:	4c 89 43 30          	mov    %r8,0x30(%rbx)
     2dc:	45 31 c0             	xor    %r8d,%r8d
     2df:	0f 11 40 20          	movups %xmm0,0x20(%rax)
     2e3:	f3 0f 6f 44 24 48    	movdqu 0x48(%rsp),%xmm0
     2e9:	66 89 48 0c          	mov    %cx,0xc(%rax)
     2ed:	31 c9                	xor    %ecx,%ecx
     2ef:	88 50 0e             	mov    %dl,0xe(%rax)
     2f2:	48 89 da             	mov    %rbx,%rdx
     2f5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
     2f9:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
     300:	5b                   	pop    %rbx
     301:	5e                   	pop    %rsi
     302:	5f                   	pop    %rdi
     303:	5d                   	pop    %rbp
     304:	41 5c                	pop    %r12
     306:	41 5d                	pop    %r13
     308:	41 5e                	pop    %r14
     30a:	41 5f                	pop    %r15
     30c:	e9 00 00 00 00       	jmp    311 <tcp_respond+0x1e1>
			30d: IMAGE_REL_AMD64_REL32	ip6_output
     311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     318:	66 41 0f 6e 45 30    	movd   0x30(%r13),%xmm0
     31e:	44 88 64 24 3b       	mov    %r12b,0x3b(%rsp)
     323:	49 c1 45 08 20       	rolq   $0x20,0x8(%r13)
     328:	f2 0f 70 c0 e1       	pshuflw $0xe1,%xmm0,%xmm0
     32d:	66 41 0f 7e 45 30    	movd   %xmm0,0x30(%r13)
     333:	e9 b2 fe ff ff       	jmp    1ea <tcp_respond+0xba>
     338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     33f:	00 
     340:	48 8b 48 30          	mov    0x30(%rax),%rcx
     344:	e8 00 00 00 00       	call   349 <tcp_respond+0x219>
			345: IMAGE_REL_AMD64_REL32	m_get
     349:	48 89 c3             	mov    %rax,%rbx
     34c:	48 85 c0             	test   %rax,%rax
     34f:	0f 84 eb 01 00 00    	je     540 <tcp_respond+0x410>
     355:	48 8b 40 30          	mov    0x30(%rax),%rax
     359:	48 8d 50 10          	lea    0x10(%rax),%rdx
     35d:	48 89 53 30          	mov    %rdx,0x30(%rbx)
     361:	f3 41 0f 6f 45 00    	movdqu 0x0(%r13),%xmm0
     367:	0f 11 40 10          	movups %xmm0,0x10(%rax)
     36b:	f3 41 0f 6f 45 10    	movdqu 0x10(%r13),%xmm0
     371:	0f 11 40 20          	movups %xmm0,0x20(%rax)
     375:	f3 41 0f 6f 45 20    	movdqu 0x20(%r13),%xmm0
     37b:	0f 11 40 30          	movups %xmm0,0x30(%rax)
     37f:	f3 41 0f 6f 45 30    	movdqu 0x30(%r13),%xmm0
     385:	0f 11 40 40          	movups %xmm0,0x40(%rax)
     389:	41 8b 55 40          	mov    0x40(%r13),%edx
     38d:	89 50 50             	mov    %edx,0x50(%rax)
     390:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
     394:	66 83 fd 02          	cmp    $0x2,%bp
     398:	0f 84 c2 01 00 00    	je     560 <tcp_respond+0x430>
     39e:	66 83 fd 17          	cmp    $0x17,%bp
     3a2:	0f 85 10 02 00 00    	jne    5b8 <tcp_respond+0x488>
     3a8:	41 c6 45 28 00       	movb   $0x0,0x28(%r13)
     3ad:	c6 44 24 3b 10       	movb   $0x10,0x3b(%rsp)
     3b2:	41 bc 10 00 00 00    	mov    $0x10,%r12d
     3b8:	e9 2d fe ff ff       	jmp    1ea <tcp_respond+0xba>
     3bd:	0f 1f 00             	nopl   (%rax)
     3c0:	8b 73 38             	mov    0x38(%rbx),%esi
     3c3:	48 8d 50 1c          	lea    0x1c(%rax),%rdx
     3c7:	0f b6 48 11          	movzbl 0x11(%rax),%ecx
     3cb:	41 83 e4 04          	and    $0x4,%r12d
     3cf:	48 89 53 30          	mov    %rdx,0x30(%rbx)
     3d3:	41 83 fc 01          	cmp    $0x1,%r12d
     3d7:	8d 56 e4             	lea    -0x1c(%rsi),%edx
     3da:	89 53 38             	mov    %edx,0x38(%rbx)
     3dd:	66 89 50 1e          	mov    %dx,0x1e(%rax)
     3e1:	8b 54 24 4c          	mov    0x4c(%rsp),%edx
     3e5:	88 48 25             	mov    %cl,0x25(%rax)
     3e8:	89 50 2c             	mov    %edx,0x2c(%rax)
     3eb:	8b 54 24 48          	mov    0x48(%rsp),%edx
     3ef:	89 50 28             	mov    %edx,0x28(%rax)
     3f2:	19 d2                	sbb    %edx,%edx
     3f4:	31 c9                	xor    %ecx,%ecx
     3f6:	83 e2 41             	and    $0x41,%edx
     3f9:	83 ea 01             	sub    $0x1,%edx
     3fc:	88 50 24             	mov    %dl,0x24(%rax)
     3ff:	48 89 da             	mov    %rbx,%rdx
     402:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
     409:	5b                   	pop    %rbx
     40a:	5e                   	pop    %rsi
     40b:	5f                   	pop    %rdi
     40c:	5d                   	pop    %rbp
     40d:	41 5c                	pop    %r12
     40f:	41 5d                	pop    %r13
     411:	41 5e                	pop    %r14
     413:	41 5f                	pop    %r15
     415:	e9 00 00 00 00       	jmp    41a <tcp_respond+0x2ea>
			416: IMAGE_REL_AMD64_REL32	ip_output
     41a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     420:	4c 8d 05 30 00 00 00 	lea    0x30(%rip),%r8        # 457 <tcp_respond+0x327>
			423: IMAGE_REL_AMD64_REL32	.rdata
     427:	ba 80 00 00 00       	mov    $0x80,%edx
     42c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 45d <tcp_respond+0x32d>
			42f: IMAGE_REL_AMD64_REL32	.rdata
     433:	e8 00 00 00 00       	call   438 <tcp_respond+0x308>
			434: IMAGE_REL_AMD64_REL32	g_log
     438:	f6 07 01             	testb  $0x1,(%rdi)
     43b:	0f 84 38 fd ff ff    	je     179 <tcp_respond+0x49>
     441:	49 89 f1             	mov    %rsi,%r9
     444:	4c 8d 05 3f 00 00 00 	lea    0x3f(%rip),%r8        # 48a <tcp_respond+0x35a>
			447: IMAGE_REL_AMD64_REL32	.rdata
     44b:	ba 80 00 00 00       	mov    $0x80,%edx
     450:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 481 <tcp_respond+0x351>
			453: IMAGE_REL_AMD64_REL32	.rdata
     457:	e8 00 00 00 00       	call   45c <tcp_respond+0x32c>
			458: IMAGE_REL_AMD64_REL32	g_log
     45c:	f6 07 01             	testb  $0x1,(%rdi)
     45f:	0f 84 14 fd ff ff    	je     179 <tcp_respond+0x49>
     465:	4d 89 e9             	mov    %r13,%r9
     468:	4c 8d 05 48 00 00 00 	lea    0x48(%rip),%r8        # 4b7 <tcp_respond+0x387>
			46b: IMAGE_REL_AMD64_REL32	.rdata
     46f:	ba 80 00 00 00       	mov    $0x80,%edx
     474:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 4a5 <tcp_respond+0x375>
			477: IMAGE_REL_AMD64_REL32	.rdata
     47b:	e8 00 00 00 00       	call   480 <tcp_respond+0x350>
			47c: IMAGE_REL_AMD64_REL32	g_log
     480:	f6 07 01             	testb  $0x1,(%rdi)
     483:	0f 84 f0 fc ff ff    	je     179 <tcp_respond+0x49>
     489:	49 89 d9             	mov    %rbx,%r9
     48c:	4c 8d 05 51 00 00 00 	lea    0x51(%rip),%r8        # 4e4 <tcp_respond+0x3b4>
			48f: IMAGE_REL_AMD64_REL32	.rdata
     493:	ba 80 00 00 00       	mov    $0x80,%edx
     498:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 4c9 <tcp_respond+0x399>
			49b: IMAGE_REL_AMD64_REL32	.rdata
     49f:	e8 00 00 00 00       	call   4a4 <tcp_respond+0x374>
			4a0: IMAGE_REL_AMD64_REL32	g_log
     4a4:	f6 07 01             	testb  $0x1,(%rdi)
     4a7:	0f 84 cc fc ff ff    	je     179 <tcp_respond+0x49>
     4ad:	44 8b 4c 24 34       	mov    0x34(%rsp),%r9d
     4b2:	4c 8d 05 59 00 00 00 	lea    0x59(%rip),%r8        # 512 <tcp_respond+0x3e2>
			4b5: IMAGE_REL_AMD64_REL32	.rdata
     4b9:	ba 80 00 00 00       	mov    $0x80,%edx
     4be:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 4ef <tcp_respond+0x3bf>
			4c1: IMAGE_REL_AMD64_REL32	.rdata
     4c5:	e8 00 00 00 00       	call   4ca <tcp_respond+0x39a>
			4c6: IMAGE_REL_AMD64_REL32	g_log
     4ca:	f6 07 01             	testb  $0x1,(%rdi)
     4cd:	0f 84 a6 fc ff ff    	je     179 <tcp_respond+0x49>
     4d3:	45 89 f1             	mov    %r14d,%r9d
     4d6:	4c 8d 05 63 00 00 00 	lea    0x63(%rip),%r8        # 540 <tcp_respond+0x410>
			4d9: IMAGE_REL_AMD64_REL32	.rdata
     4dd:	ba 80 00 00 00       	mov    $0x80,%edx
     4e2:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 513 <tcp_respond+0x3e3>
			4e5: IMAGE_REL_AMD64_REL32	.rdata
     4e9:	e8 00 00 00 00       	call   4ee <tcp_respond+0x3be>
			4ea: IMAGE_REL_AMD64_REL32	g_log
     4ee:	f6 07 01             	testb  $0x1,(%rdi)
     4f1:	0f 84 82 fc ff ff    	je     179 <tcp_respond+0x49>
     4f7:	45 89 e1             	mov    %r12d,%r9d
     4fa:	4c 8d 05 6d 00 00 00 	lea    0x6d(%rip),%r8        # 56e <tcp_respond+0x43e>
			4fd: IMAGE_REL_AMD64_REL32	.rdata
     501:	ba 80 00 00 00       	mov    $0x80,%edx
     506:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 537 <tcp_respond+0x407>
			509: IMAGE_REL_AMD64_REL32	.rdata
     50d:	e8 00 00 00 00       	call   512 <tcp_respond+0x3e2>
			50e: IMAGE_REL_AMD64_REL32	g_log
     512:	48 85 f6             	test   %rsi,%rsi
     515:	0f 85 67 fc ff ff    	jne    182 <tcp_respond+0x52>
     51b:	48 85 db             	test   %rbx,%rbx
     51e:	74 20                	je     540 <tcp_respond+0x410>
     520:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
     527:	00 
     528:	31 ff                	xor    %edi,%edi
     52a:	e9 70 fc ff ff       	jmp    19f <tcp_respond+0x6f>
     52f:	90                   	nop
     530:	0f b7 cf             	movzwl %di,%ecx
     533:	41 ff d7             	call   *%r15
     536:	e9 1f fd ff ff       	jmp    25a <tcp_respond+0x12a>
     53b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     540:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
     547:	5b                   	pop    %rbx
     548:	5e                   	pop    %rsi
     549:	5f                   	pop    %rdi
     54a:	5d                   	pop    %rbp
     54b:	41 5c                	pop    %r12
     54d:	41 5d                	pop    %r13
     54f:	41 5e                	pop    %r14
     551:	41 5f                	pop    %r15
     553:	31 c0                	xor    %eax,%eax
     555:	31 d2                	xor    %edx,%edx
     557:	31 c9                	xor    %ecx,%ecx
     559:	45 31 c0             	xor    %r8d,%r8d
     55c:	45 31 c9             	xor    %r9d,%r9d
     55f:	c3                   	ret
     560:	41 c6 45 10 00       	movb   $0x0,0x10(%r13)
     565:	e9 43 fe ff ff       	jmp    3ad <tcp_respond+0x27d>
     56a:	31 c0                	xor    %eax,%eax
     56c:	4c 8d 0d 80 03 00 00 	lea    0x380(%rip),%r9        # 8f3 <tcp_sockclosed+0x3>
			56f: IMAGE_REL_AMD64_REL32	.rdata
     573:	41 b8 f0 00 00 00    	mov    $0xf0,%r8d
     579:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
     57e:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 585 <tcp_respond+0x455>
			581: IMAGE_REL_AMD64_REL32	.rdata
     585:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 5b6 <tcp_respond+0x486>
			588: IMAGE_REL_AMD64_REL32	.rdata
     58c:	e8 00 00 00 00       	call   591 <tcp_respond+0x461>
			58d: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
     591:	31 c9                	xor    %ecx,%ecx
     593:	4c 8d 0d 80 03 00 00 	lea    0x380(%rip),%r9        # 91a <tcp_sockclosed+0x2a>
			596: IMAGE_REL_AMD64_REL32	.rdata
     59a:	41 b8 b1 00 00 00    	mov    $0xb1,%r8d
     5a0:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
     5a5:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 5ac <tcp_respond+0x47c>
			5a8: IMAGE_REL_AMD64_REL32	.rdata
     5ac:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 5dd <tcp_respond+0x4ad>
			5af: IMAGE_REL_AMD64_REL32	.rdata
     5b3:	e8 00 00 00 00       	call   5b8 <tcp_respond+0x488>
			5b4: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
     5b8:	45 31 c0             	xor    %r8d,%r8d
     5bb:	4c 8d 0d 80 03 00 00 	lea    0x380(%rip),%r9        # 942 <tcp_sockclosed+0x52>
			5be: IMAGE_REL_AMD64_REL32	.rdata
     5c2:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 5c9 <tcp_respond+0x499>
			5c5: IMAGE_REL_AMD64_REL32	.rdata
     5c9:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
     5ce:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 5ff <tcp_newtcpcb+0xf>
			5d1: IMAGE_REL_AMD64_REL32	.rdata
     5d5:	41 b8 94 00 00 00    	mov    $0x94,%r8d
     5db:	e8 00 00 00 00       	call   5e0 <tcp_respond+0x4b0>
			5dc: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
     5e0:	90                   	nop
     5e1:	0f 1f 40 00          	nopl   0x0(%rax)
     5e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     5ec:	00 00 00 00 

00000000000005f0 <tcp_newtcpcb>:
     5f0:	53                   	push   %rbx
     5f1:	48 83 ec 20          	sub    $0x20,%rsp
     5f5:	48 89 cb             	mov    %rcx,%rbx
     5f8:	b9 e0 00 00 00       	mov    $0xe0,%ecx
     5fd:	e8 00 00 00 00       	call   602 <tcp_newtcpcb+0x12>
			5fe: IMAGE_REL_AMD64_REL32	g_malloc0
     602:	48 8b 53 30          	mov    0x30(%rbx),%rdx
     606:	66 83 7b 50 02       	cmpw   $0x2,0x50(%rbx)
     60b:	41 b8 28 00 00 00    	mov    $0x28,%r8d
     611:	b9 3c 00 00 00       	mov    $0x3c,%ecx
     616:	48 89 40 08          	mov    %rax,0x8(%rax)
     61a:	41 0f 44 c8          	cmove  %r8d,%ecx
     61e:	48 89 00             	mov    %rax,(%rax)
     621:	8b 92 90 00 00 00    	mov    0x90(%rdx),%edx
     627:	41 b8 0c 00 00 00    	mov    $0xc,%r8d
     62d:	48 89 58 70          	mov    %rbx,0x70(%rax)
     631:	29 ca                	sub    %ecx,%edx
     633:	b9 00 80 00 00       	mov    $0x8000,%ecx
     638:	c7 80 bc 00 00 00 00 	movl   $0x180000,0xbc(%rax)
     63f:	00 18 00 
     642:	39 ca                	cmp    %ecx,%edx
     644:	66 44 89 40 1c       	mov    %r8w,0x1c(%rax)
     649:	0f 4f d1             	cmovg  %ecx,%edx
     64c:	b9 02 00 00 00       	mov    $0x2,%ecx
     651:	45 31 c9             	xor    %r9d,%r9d
     654:	48 89 83 58 01 00 00 	mov    %rax,0x158(%rbx)
     65b:	66 89 88 c0 00 00 00 	mov    %cx,0xc0(%rax)
     662:	66 89 50 20          	mov    %dx,0x20(%rax)
     666:	31 d2                	xor    %edx,%edx
     668:	66 89 50 24          	mov    %dx,0x24(%rax)
     66c:	48 ba 00 c0 ff 3f 00 	movabs $0x3fffc0003fffc000,%rdx
     673:	c0 ff 3f 
     676:	48 89 90 ac 00 00 00 	mov    %rdx,0xac(%rax)
     67d:	66 44 89 48 10       	mov    %r9w,0x10(%rax)
     682:	48 83 c4 20          	add    $0x20,%rsp
     686:	5b                   	pop    %rbx
     687:	31 d2                	xor    %edx,%edx
     689:	31 c9                	xor    %ecx,%ecx
     68b:	45 31 c0             	xor    %r8d,%r8d
     68e:	45 31 c9             	xor    %r9d,%r9d
     691:	c3                   	ret
     692:	0f 1f 00             	nopl   (%rax)
     695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     69c:	00 00 00 00 

00000000000006a0 <tcp_close>:
     6a0:	41 55                	push   %r13
     6a2:	41 54                	push   %r12
     6a4:	55                   	push   %rbp
     6a5:	57                   	push   %rdi
     6a6:	56                   	push   %rsi
     6a7:	53                   	push   %rbx
     6a8:	48 83 ec 28          	sub    $0x28,%rsp
     6ac:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # 6b3 <tcp_close+0x13>
			6af: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     6b3:	4c 8b 61 70          	mov    0x70(%rcx),%r12
     6b7:	4d 8b 6c 24 30       	mov    0x30(%r12),%r13
     6bc:	48 89 cd             	mov    %rcx,%rbp
     6bf:	f6 03 01             	testb  $0x1,(%rbx)
     6c2:	0f 85 a8 00 00 00    	jne    770 <tcp_close+0xd0>
     6c8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
     6cc:	48 39 ee             	cmp    %rbp,%rsi
     6cf:	74 31                	je     702 <tcp_close+0x62>
     6d1:	48 83 c6 10          	add    $0x10,%rsi
     6d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     6dc:	00 00 00 00 
     6e0:	48 8b 5e f0          	mov    -0x10(%rsi),%rbx
     6e4:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
     6e8:	48 8d 73 10          	lea    0x10(%rbx),%rsi
     6ec:	48 8b 79 10          	mov    0x10(%rcx),%rdi
     6f0:	e8 00 00 00 00       	call   6f5 <tcp_close+0x55>
			6f1: IMAGE_REL_AMD64_REL32	slirp_remque
     6f5:	48 89 f9             	mov    %rdi,%rcx
     6f8:	e8 00 00 00 00       	call   6fd <tcp_close+0x5d>
			6f9: IMAGE_REL_AMD64_REL32	m_free
     6fd:	48 39 eb             	cmp    %rbp,%rbx
     700:	75 de                	jne    6e0 <tcp_close+0x40>
     702:	48 89 e9             	mov    %rbp,%rcx
     705:	e8 00 00 00 00       	call   70a <tcp_close+0x6a>
			706: IMAGE_REL_AMD64_REL32	g_free
     70a:	49 c7 84 24 58 01 00 	movq   $0x0,0x158(%r12)
     711:	00 00 00 00 00 
     716:	4d 39 a5 70 03 00 00 	cmp    %r12,0x370(%r13)
     71d:	0f 84 95 00 00 00    	je     7b8 <tcp_close+0x118>
     723:	4c 89 e1             	mov    %r12,%rcx
     726:	e8 00 00 00 00       	call   72b <tcp_close+0x8b>
			727: IMAGE_REL_AMD64_REL32	slirp_unregister_poll_socket
     72b:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
     730:	e8 00 00 00 00       	call   735 <tcp_close+0x95>
			731: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
     735:	49 8d 8c 24 70 01 00 	lea    0x170(%r12),%rcx
     73c:	00 
     73d:	e8 00 00 00 00       	call   742 <tcp_close+0xa2>
			73e: IMAGE_REL_AMD64_REL32	sbfree
     742:	49 8d 8c 24 90 01 00 	lea    0x190(%r12),%rcx
     749:	00 
     74a:	e8 00 00 00 00       	call   74f <tcp_close+0xaf>
			74b: IMAGE_REL_AMD64_REL32	sbfree
     74f:	4c 89 e1             	mov    %r12,%rcx
     752:	e8 00 00 00 00       	call   757 <tcp_close+0xb7>
			753: IMAGE_REL_AMD64_REL32	sofree
     757:	31 c0                	xor    %eax,%eax
     759:	48 83 c4 28          	add    $0x28,%rsp
     75d:	5b                   	pop    %rbx
     75e:	5e                   	pop    %rsi
     75f:	5f                   	pop    %rdi
     760:	5d                   	pop    %rbp
     761:	41 5c                	pop    %r12
     763:	41 5d                	pop    %r13
     765:	31 d2                	xor    %edx,%edx
     767:	31 c9                	xor    %ecx,%ecx
     769:	45 31 c0             	xor    %r8d,%r8d
     76c:	45 31 c9             	xor    %r9d,%r9d
     76f:	c3                   	ret
     770:	4c 8d 05 79 00 00 00 	lea    0x79(%rip),%r8        # 7f0 <tcp_cleanup+0x20>
			773: IMAGE_REL_AMD64_REL32	.rdata
     777:	ba 80 00 00 00       	mov    $0x80,%edx
     77c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 7ad <tcp_close+0x10d>
			77f: IMAGE_REL_AMD64_REL32	.rdata
     783:	e8 00 00 00 00       	call   788 <tcp_close+0xe8>
			784: IMAGE_REL_AMD64_REL32	g_log
     788:	f6 03 01             	testb  $0x1,(%rbx)
     78b:	0f 84 37 ff ff ff    	je     6c8 <tcp_close+0x28>
     791:	49 89 e9             	mov    %rbp,%r9
     794:	4c 8d 05 3f 00 00 00 	lea    0x3f(%rip),%r8        # 7da <tcp_cleanup+0xa>
			797: IMAGE_REL_AMD64_REL32	.rdata
     79b:	ba 80 00 00 00       	mov    $0x80,%edx
     7a0:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 7d1 <tcp_cleanup+0x1>
			7a3: IMAGE_REL_AMD64_REL32	.rdata
     7a7:	e8 00 00 00 00       	call   7ac <tcp_close+0x10c>
			7a8: IMAGE_REL_AMD64_REL32	g_log
     7ac:	e9 17 ff ff ff       	jmp    6c8 <tcp_close+0x28>
     7b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     7b8:	49 8d 85 c0 01 00 00 	lea    0x1c0(%r13),%rax
     7bf:	49 89 85 70 03 00 00 	mov    %rax,0x370(%r13)
     7c6:	e9 58 ff ff ff       	jmp    723 <tcp_close+0x83>
     7cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000007d0 <tcp_cleanup>:
     7d0:	56                   	push   %rsi
     7d1:	53                   	push   %rbx
     7d2:	48 83 ec 28          	sub    $0x28,%rsp
     7d6:	48 8b 81 c0 01 00 00 	mov    0x1c0(%rcx),%rax
     7dd:	48 8d b1 c0 01 00 00 	lea    0x1c0(%rcx),%rsi
     7e4:	48 89 cb             	mov    %rcx,%rbx
     7e7:	48 39 f0             	cmp    %rsi,%rax
     7ea:	74 1c                	je     808 <tcp_cleanup+0x38>
     7ec:	0f 1f 40 00          	nopl   0x0(%rax)
     7f0:	48 8b 88 58 01 00 00 	mov    0x158(%rax),%rcx
     7f7:	e8 a4 fe ff ff       	call   6a0 <tcp_close>
     7fc:	48 8b 83 c0 01 00 00 	mov    0x1c0(%rbx),%rax
     803:	48 39 f0             	cmp    %rsi,%rax
     806:	75 e8                	jne    7f0 <tcp_cleanup+0x20>
     808:	48 83 c4 28          	add    $0x28,%rsp
     80c:	5b                   	pop    %rbx
     80d:	5e                   	pop    %rsi
     80e:	31 c0                	xor    %eax,%eax
     810:	31 c9                	xor    %ecx,%ecx
     812:	c3                   	ret
     813:	66 90                	xchg   %ax,%ax
     815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     81c:	00 00 00 00 

0000000000000820 <tcp_drop>:
     820:	53                   	push   %rbx
     821:	48 83 ec 20          	sub    $0x20,%rsp
     825:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 82c <tcp_drop+0xc>
			828: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     82c:	48 89 cb             	mov    %rcx,%rbx
     82f:	f6 00 01             	testb  $0x1,(%rax)
     832:	75 1c                	jne    850 <tcp_drop+0x30>
     834:	66 83 7b 10 02       	cmpw   $0x2,0x10(%rbx)
     839:	0f 8f 88 00 00 00    	jg     8c7 <tcp_drop+0xa7>
     83f:	48 89 d9             	mov    %rbx,%rcx
     842:	48 83 c4 20          	add    $0x20,%rsp
     846:	5b                   	pop    %rbx
     847:	e9 54 fe ff ff       	jmp    6a0 <tcp_close>
     84c:	0f 1f 40 00          	nopl   0x0(%rax)
     850:	4c 8d 05 86 00 00 00 	lea    0x86(%rip),%r8        # 8dd <tcp_drop+0xbd>
			853: IMAGE_REL_AMD64_REL32	.rdata
     857:	ba 80 00 00 00       	mov    $0x80,%edx
     85c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 88d <tcp_drop+0x6d>
			85f: IMAGE_REL_AMD64_REL32	.rdata
     863:	e8 00 00 00 00       	call   868 <tcp_drop+0x48>
			864: IMAGE_REL_AMD64_REL32	g_log
     868:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 86f <tcp_drop+0x4f>
			86b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     86f:	f6 00 01             	testb  $0x1,(%rax)
     872:	74 c0                	je     834 <tcp_drop+0x14>
     874:	49 89 d9             	mov    %rbx,%r9
     877:	4c 8d 05 3f 00 00 00 	lea    0x3f(%rip),%r8        # 8bd <tcp_drop+0x9d>
			87a: IMAGE_REL_AMD64_REL32	.rdata
     87e:	ba 80 00 00 00       	mov    $0x80,%edx
     883:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 8b4 <tcp_drop+0x94>
			886: IMAGE_REL_AMD64_REL32	.rdata
     88a:	e8 00 00 00 00       	call   88f <tcp_drop+0x6f>
			88b: IMAGE_REL_AMD64_REL32	g_log
     88f:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 896 <tcp_drop+0x76>
			892: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     896:	f6 00 01             	testb  $0x1,(%rax)
     899:	74 99                	je     834 <tcp_drop+0x14>
     89b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 8a1 <tcp_drop+0x81>
			89d: IMAGE_REL_AMD64_REL32	__imp__errno
     8a1:	4c 8d 05 92 00 00 00 	lea    0x92(%rip),%r8        # 93a <tcp_sockclosed+0x4a>
			8a4: IMAGE_REL_AMD64_REL32	.rdata
     8a8:	ba 80 00 00 00       	mov    $0x80,%edx
     8ad:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 8de <tcp_drop+0xbe>
			8b0: IMAGE_REL_AMD64_REL32	.rdata
     8b4:	44 8b 08             	mov    (%rax),%r9d
     8b7:	e8 00 00 00 00       	call   8bc <tcp_drop+0x9c>
			8b8: IMAGE_REL_AMD64_REL32	g_log
     8bc:	66 83 7b 10 02       	cmpw   $0x2,0x10(%rbx)
     8c1:	0f 8e 78 ff ff ff    	jle    83f <tcp_drop+0x1f>
     8c7:	31 c0                	xor    %eax,%eax
     8c9:	48 89 d9             	mov    %rbx,%rcx
     8cc:	66 89 43 10          	mov    %ax,0x10(%rbx)
     8d0:	e8 00 00 00 00       	call   8d5 <tcp_drop+0xb5>
			8d1: IMAGE_REL_AMD64_REL32	tcp_output
     8d5:	48 89 d9             	mov    %rbx,%rcx
     8d8:	48 83 c4 20          	add    $0x20,%rsp
     8dc:	5b                   	pop    %rbx
     8dd:	e9 be fd ff ff       	jmp    6a0 <tcp_close>
     8e2:	0f 1f 00             	nopl   (%rax)
     8e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     8ec:	00 00 00 00 

00000000000008f0 <tcp_sockclosed>:
     8f0:	53                   	push   %rbx
     8f1:	48 83 ec 20          	sub    $0x20,%rsp
     8f5:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 8fc <tcp_sockclosed+0xc>
			8f8: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     8fc:	48 89 cb             	mov    %rcx,%rbx
     8ff:	f6 00 01             	testb  $0x1,(%rax)
     902:	75 5c                	jne    960 <tcp_sockclosed+0x70>
     904:	48 85 db             	test   %rbx,%rbx
     907:	0f 84 9b 00 00 00    	je     9a8 <tcp_sockclosed+0xb8>
     90d:	0f b7 43 10          	movzwl 0x10(%rbx),%eax
     911:	66 83 f8 05          	cmp    $0x5,%ax
     915:	0f 84 c5 00 00 00    	je     9e0 <tcp_sockclosed+0xf0>
     91b:	7f 23                	jg     940 <tcp_sockclosed+0x50>
     91d:	66 83 f8 02          	cmp    $0x2,%ax
     921:	0f 8e 99 00 00 00    	jle    9c0 <tcp_sockclosed+0xd0>
     927:	41 b8 06 00 00 00    	mov    $0x6,%r8d
     92d:	66 44 89 43 10       	mov    %r8w,0x10(%rbx)
     932:	48 89 d9             	mov    %rbx,%rcx
     935:	48 83 c4 20          	add    $0x20,%rsp
     939:	5b                   	pop    %rbx
     93a:	e9 00 00 00 00       	jmp    93f <tcp_sockclosed+0x4f>
			93b: IMAGE_REL_AMD64_REL32	tcp_output
     93f:	90                   	nop
     940:	83 e8 06             	sub    $0x6,%eax
     943:	66 83 f8 04          	cmp    $0x4,%ax
     947:	77 e9                	ja     932 <tcp_sockclosed+0x42>
     949:	b8 78 00 00 00       	mov    $0x78,%eax
     94e:	48 89 d9             	mov    %rbx,%rcx
     951:	66 89 43 18          	mov    %ax,0x18(%rbx)
     955:	48 83 c4 20          	add    $0x20,%rsp
     959:	5b                   	pop    %rbx
     95a:	e9 00 00 00 00       	jmp    95f <tcp_sockclosed+0x6f>
			95b: IMAGE_REL_AMD64_REL32	tcp_output
     95f:	90                   	nop
     960:	4c 8d 05 9e 00 00 00 	lea    0x9e(%rip),%r8        # a05 <tcp_fconnect+0x5>
			963: IMAGE_REL_AMD64_REL32	.rdata
     967:	ba 80 00 00 00       	mov    $0x80,%edx
     96c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 99d <tcp_sockclosed+0xad>
			96f: IMAGE_REL_AMD64_REL32	.rdata
     973:	e8 00 00 00 00       	call   978 <tcp_sockclosed+0x88>
			974: IMAGE_REL_AMD64_REL32	g_log
     978:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 97f <tcp_sockclosed+0x8f>
			97b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     97f:	f6 00 01             	testb  $0x1,(%rax)
     982:	74 80                	je     904 <tcp_sockclosed+0x14>
     984:	49 89 d9             	mov    %rbx,%r9
     987:	4c 8d 05 3f 00 00 00 	lea    0x3f(%rip),%r8        # 9cd <tcp_sockclosed+0xdd>
			98a: IMAGE_REL_AMD64_REL32	.rdata
     98e:	ba 80 00 00 00       	mov    $0x80,%edx
     993:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 9c4 <tcp_sockclosed+0xd4>
			996: IMAGE_REL_AMD64_REL32	.rdata
     99a:	e8 00 00 00 00       	call   99f <tcp_sockclosed+0xaf>
			99b: IMAGE_REL_AMD64_REL32	g_log
     99f:	48 85 db             	test   %rbx,%rbx
     9a2:	0f 85 65 ff ff ff    	jne    90d <tcp_sockclosed+0x1d>
     9a8:	48 83 c4 20          	add    $0x20,%rsp
     9ac:	5b                   	pop    %rbx
     9ad:	31 c0                	xor    %eax,%eax
     9af:	31 d2                	xor    %edx,%edx
     9b1:	31 c9                	xor    %ecx,%ecx
     9b3:	45 31 c0             	xor    %r8d,%r8d
     9b6:	45 31 c9             	xor    %r9d,%r9d
     9b9:	c3                   	ret
     9ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     9c0:	66 85 c0             	test   %ax,%ax
     9c3:	0f 88 69 ff ff ff    	js     932 <tcp_sockclosed+0x42>
     9c9:	31 c9                	xor    %ecx,%ecx
     9cb:	66 89 4b 10          	mov    %cx,0x10(%rbx)
     9cf:	48 89 d9             	mov    %rbx,%rcx
     9d2:	48 83 c4 20          	add    $0x20,%rsp
     9d6:	5b                   	pop    %rbx
     9d7:	e9 c4 fc ff ff       	jmp    6a0 <tcp_close>
     9dc:	0f 1f 40 00          	nopl   0x0(%rax)
     9e0:	ba 08 00 00 00       	mov    $0x8,%edx
     9e5:	48 89 d9             	mov    %rbx,%rcx
     9e8:	66 89 53 10          	mov    %dx,0x10(%rbx)
     9ec:	48 83 c4 20          	add    $0x20,%rsp
     9f0:	5b                   	pop    %rbx
     9f1:	e9 00 00 00 00       	jmp    9f6 <tcp_sockclosed+0x106>
			9f2: IMAGE_REL_AMD64_REL32	tcp_output
     9f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     9fd:	00 00 00 

0000000000000a00 <tcp_fconnect>:
     a00:	57                   	push   %rdi
     a01:	56                   	push   %rsi
     a02:	53                   	push   %rbx
     a03:	48 81 ec c0 00 00 00 	sub    $0xc0,%rsp
     a0a:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # a11 <tcp_fconnect+0x11>
			a0d: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     a11:	48 89 cb             	mov    %rcx,%rbx
     a14:	89 d6                	mov    %edx,%esi
     a16:	f6 00 01             	testb  $0x1,(%rax)
     a19:	0f 85 e1 01 00 00    	jne    c00 <tcp_fconnect+0x200>
     a1f:	45 31 c0             	xor    %r8d,%r8d
     a22:	ba 01 00 00 00       	mov    $0x1,%edx
     a27:	0f b7 ce             	movzwl %si,%ecx
     a2a:	e8 00 00 00 00       	call   a2f <tcp_fconnect+0x2f>
			a2b: IMAGE_REL_AMD64_REL32	slirp_socket
     a2f:	48 89 43 10          	mov    %rax,0x10(%rbx)
     a33:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
     a37:	0f 84 43 02 00 00    	je     c80 <tcp_fconnect+0x280>
     a3d:	0f b7 d6             	movzwl %si,%edx
     a40:	48 89 d9             	mov    %rbx,%rcx
     a43:	e8 00 00 00 00       	call   a48 <tcp_fconnect+0x48>
			a44: IMAGE_REL_AMD64_REL32	slirp_bind_outbound
     a48:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
     a4c:	89 c6                	mov    %eax,%esi
     a4e:	85 c0                	test   %eax,%eax
     a50:	0f 88 fa 01 00 00    	js     c50 <tcp_fconnect+0x250>
     a56:	66 0f ef c0          	pxor   %xmm0,%xmm0
     a5a:	48 89 f9             	mov    %rdi,%rcx
     a5d:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
     a64:	00 
     a65:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
     a6a:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
     a6f:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
     a74:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     a79:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
     a80:	00 
     a81:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
     a88:	00 
     a89:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
     a90:	00 
     a91:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
     a98:	00 
     a99:	e8 00 00 00 00       	call   a9e <tcp_fconnect+0x9e>
			a9a: IMAGE_REL_AMD64_REL32	slirp_set_nonblock
     a9e:	48 89 d9             	mov    %rbx,%rcx
     aa1:	e8 00 00 00 00       	call   aa6 <tcp_fconnect+0xa6>
			aa2: IMAGE_REL_AMD64_REL32	slirp_register_poll_socket
     aa6:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
     aad:	00 
     aae:	4c 8d 4c 24 3c       	lea    0x3c(%rsp),%r9
     ab3:	48 89 f9             	mov    %rdi,%rcx
     ab6:	41 b8 00 01 00 00    	mov    $0x100,%r8d
     abc:	ba ff ff 00 00       	mov    $0xffff,%edx
     ac1:	c7 44 24 3c 01 00 00 	movl   $0x1,0x3c(%rsp)
     ac8:	00 
     ac9:	e8 00 00 00 00       	call   ace <tcp_fconnect+0xce>
			aca: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
     ace:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
     ad5:	00 
     ad6:	4c 8d 4c 24 3c       	lea    0x3c(%rsp),%r9
     adb:	48 89 f9             	mov    %rdi,%rcx
     ade:	41 b8 01 00 00 00    	mov    $0x1,%r8d
     ae4:	ba 06 00 00 00       	mov    $0x6,%edx
     ae9:	c7 44 24 3c 01 00 00 	movl   $0x1,0x3c(%rsp)
     af0:	00 
     af1:	e8 00 00 00 00       	call   af6 <tcp_fconnect+0xf6>
			af2: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
     af6:	f3 0f 6f 43 50       	movdqu 0x50(%rbx),%xmm0
     afb:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # b02 <tcp_fconnect+0x102>
			afe: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     b02:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
     b07:	f3 0f 6f 43 60       	movdqu 0x60(%rbx),%xmm0
     b0c:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
     b11:	f3 0f 6f 43 70       	movdqu 0x70(%rbx),%xmm0
     b16:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
     b1b:	f3 0f 6f 83 80 00 00 	movdqu 0x80(%rbx),%xmm0
     b22:	00 
     b23:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     b28:	f3 0f 6f 83 90 00 00 	movdqu 0x90(%rbx),%xmm0
     b2f:	00 
     b30:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
     b37:	00 
     b38:	f3 0f 6f 83 a0 00 00 	movdqu 0xa0(%rbx),%xmm0
     b3f:	00 
     b40:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
     b47:	00 
     b48:	f3 0f 6f 83 b0 00 00 	movdqu 0xb0(%rbx),%xmm0
     b4f:	00 
     b50:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
     b57:	00 
     b58:	f3 0f 6f 83 c0 00 00 	movdqu 0xc0(%rbx),%xmm0
     b5f:	00 
     b60:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
     b67:	00 
     b68:	f6 00 01             	testb  $0x1,(%rax)
     b6b:	75 73                	jne    be0 <tcp_fconnect+0x1e0>
     b6d:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
     b72:	48 89 d9             	mov    %rbx,%rcx
     b75:	e8 00 00 00 00       	call   b7a <tcp_fconnect+0x17a>
			b76: IMAGE_REL_AMD64_REL32	sotranslate_out
     b7a:	85 c0                	test   %eax,%eax
     b7c:	0f 88 fe 00 00 00    	js     c80 <tcp_fconnect+0x280>
     b82:	0f b7 44 24 40       	movzwl 0x40(%rsp),%eax
     b87:	66 83 f8 02          	cmp    $0x2,%ax
     b8b:	74 43                	je     bd0 <tcp_fconnect+0x1d0>
     b8d:	66 83 f8 17          	cmp    $0x17,%ax
     b91:	0f 85 f3 00 00 00    	jne    c8a <tcp_fconnect+0x28a>
     b97:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
     b9d:	48 89 f9             	mov    %rdi,%rcx
     ba0:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
     ba5:	e8 00 00 00 00       	call   baa <tcp_fconnect+0x1aa>
			ba6: IMAGE_REL_AMD64_REL32	slirp_connect_wrap
     baa:	48 89 d9             	mov    %rbx,%rcx
     bad:	89 c6                	mov    %eax,%esi
     baf:	e8 00 00 00 00       	call   bb4 <tcp_fconnect+0x1b4>
			bb0: IMAGE_REL_AMD64_REL32	soisfconnecting
     bb4:	89 f0                	mov    %esi,%eax
     bb6:	48 81 c4 c0 00 00 00 	add    $0xc0,%rsp
     bbd:	5b                   	pop    %rbx
     bbe:	5e                   	pop    %rsi
     bbf:	5f                   	pop    %rdi
     bc0:	31 d2                	xor    %edx,%edx
     bc2:	31 c9                	xor    %ecx,%ecx
     bc4:	45 31 c0             	xor    %r8d,%r8d
     bc7:	45 31 c9             	xor    %r9d,%r9d
     bca:	c3                   	ret
     bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     bd0:	41 b8 10 00 00 00    	mov    $0x10,%r8d
     bd6:	eb c5                	jmp    b9d <tcp_fconnect+0x19d>
     bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     bdf:	00 
     be0:	4c 8d 05 c9 00 00 00 	lea    0xc9(%rip),%r8        # cb0 <tcp_fconnect+0x2b0>
			be3: IMAGE_REL_AMD64_REL32	.rdata
     be7:	ba 80 00 00 00       	mov    $0x80,%edx
     bec:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # c1d <tcp_fconnect+0x21d>
			bef: IMAGE_REL_AMD64_REL32	.rdata
     bf3:	e8 00 00 00 00       	call   bf8 <tcp_fconnect+0x1f8>
			bf4: IMAGE_REL_AMD64_REL32	g_log
     bf8:	e9 70 ff ff ff       	jmp    b6d <tcp_fconnect+0x16d>
     bfd:	0f 1f 00             	nopl   (%rax)
     c00:	4c 8d 05 b0 00 00 00 	lea    0xb0(%rip),%r8        # cb7 <tcp_fconnect+0x2b7>
			c03: IMAGE_REL_AMD64_REL32	.rdata
     c07:	ba 80 00 00 00       	mov    $0x80,%edx
     c0c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # c3d <tcp_fconnect+0x23d>
			c0f: IMAGE_REL_AMD64_REL32	.rdata
     c13:	e8 00 00 00 00       	call   c18 <tcp_fconnect+0x218>
			c14: IMAGE_REL_AMD64_REL32	g_log
     c18:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # c1f <tcp_fconnect+0x21f>
			c1b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     c1f:	f6 00 01             	testb  $0x1,(%rax)
     c22:	0f 84 f7 fd ff ff    	je     a1f <tcp_fconnect+0x1f>
     c28:	49 89 d9             	mov    %rbx,%r9
     c2b:	4c 8d 05 c0 00 00 00 	lea    0xc0(%rip),%r8        # cf2 <tcp_tos+0x2>
			c2e: IMAGE_REL_AMD64_REL32	.rdata
     c32:	ba 80 00 00 00       	mov    $0x80,%edx
     c37:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # c68 <tcp_fconnect+0x268>
			c3a: IMAGE_REL_AMD64_REL32	.rdata
     c3e:	e8 00 00 00 00       	call   c43 <tcp_fconnect+0x243>
			c3f: IMAGE_REL_AMD64_REL32	g_log
     c43:	e9 d7 fd ff ff       	jmp    a1f <tcp_fconnect+0x1f>
     c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     c4f:	00 
     c50:	48 89 f9             	mov    %rdi,%rcx
     c53:	e8 00 00 00 00       	call   c58 <tcp_fconnect+0x258>
			c54: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
     c58:	89 f0                	mov    %esi,%eax
     c5a:	48 c7 43 10 ff ff ff 	movq   $0xffffffffffffffff,0x10(%rbx)
     c61:	ff 
     c62:	48 81 c4 c0 00 00 00 	add    $0xc0,%rsp
     c69:	5b                   	pop    %rbx
     c6a:	5e                   	pop    %rsi
     c6b:	5f                   	pop    %rdi
     c6c:	31 d2                	xor    %edx,%edx
     c6e:	31 c9                	xor    %ecx,%ecx
     c70:	45 31 c0             	xor    %r8d,%r8d
     c73:	45 31 c9             	xor    %r9d,%r9d
     c76:	c3                   	ret
     c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     c7e:	00 00 
     c80:	be ff ff ff ff       	mov    $0xffffffff,%esi
     c85:	e9 2a ff ff ff       	jmp    bb4 <tcp_fconnect+0x1b4>
     c8a:	31 c0                	xor    %eax,%eax
     c8c:	4c 8d 0d 70 03 00 00 	lea    0x370(%rip),%r9        # 1003 <tcp_connect+0x253>
			c8f: IMAGE_REL_AMD64_REL32	.rdata
     c93:	41 b8 a9 00 00 00    	mov    $0xa9,%r8d
     c99:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
     c9e:	48 8d 15 e0 00 00 00 	lea    0xe0(%rip),%rdx        # d85 <tcp_tos+0x95>
			ca1: IMAGE_REL_AMD64_REL32	.rdata
     ca5:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # cd6 <tcp_attach+0x16>
			ca8: IMAGE_REL_AMD64_REL32	.rdata
     cac:	e8 00 00 00 00       	call   cb1 <tcp_fconnect+0x2b1>
			cad: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
     cb1:	90                   	nop
     cb2:	0f 1f 00             	nopl   (%rax)
     cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     cbc:	00 00 00 00 

0000000000000cc0 <tcp_attach>:
     cc0:	48 83 ec 38          	sub    $0x38,%rsp
     cc4:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
     cc9:	e8 22 f9 ff ff       	call   5f0 <tcp_newtcpcb>
     cce:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
     cd3:	48 89 81 58 01 00 00 	mov    %rax,0x158(%rcx)
     cda:	48 8b 41 30          	mov    0x30(%rcx),%rax
     cde:	48 8d 90 c0 01 00 00 	lea    0x1c0(%rax),%rdx
     ce5:	48 83 c4 38          	add    $0x38,%rsp
     ce9:	e9 00 00 00 00       	jmp    cee <tcp_attach+0x2e>
			cea: IMAGE_REL_AMD64_REL32	slirp_insque
     cee:	66 90                	xchg   %ax,%ax

0000000000000cf0 <tcp_tos>:
     cf0:	41 56                	push   %r14
     cf2:	41 55                	push   %r13
     cf4:	41 54                	push   %r12
     cf6:	55                   	push   %rbp
     cf7:	57                   	push   %rdi
     cf8:	56                   	push   %rsi
     cf9:	53                   	push   %rbx
     cfa:	48 83 ec 20          	sub    $0x20,%rsp
     cfe:	4c 8d 2d a0 03 00 00 	lea    0x3a0(%rip),%r13        # 10a5 <tcp_connect+0x2f5>
			d01: IMAGE_REL_AMD64_REL32	.rdata
     d05:	31 ed                	xor    %ebp,%ebp
     d07:	bf 08 00 00 00       	mov    $0x8,%edi
     d0c:	4c 8b 35 00 00 00 00 	mov    0x0(%rip),%r14        # d13 <tcp_tos+0x23>
			d0f: IMAGE_REL_AMD64_REL32	__imp_ntohs
     d13:	4c 89 eb             	mov    %r13,%rbx
     d16:	49 89 cc             	mov    %rcx,%r12
     d19:	eb 1d                	jmp    d38 <tcp_tos+0x48>
     d1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     d20:	0f b7 33             	movzwl (%rbx),%esi
     d23:	66 85 f6             	test   %si,%si
     d26:	75 60                	jne    d88 <tcp_tos+0x98>
     d28:	0f b6 7b 0a          	movzbl 0xa(%rbx),%edi
     d2c:	48 83 c3 06          	add    $0x6,%rbx
     d30:	83 c5 01             	add    $0x1,%ebp
     d33:	40 84 ff             	test   %dil,%dil
     d36:	74 38                	je     d70 <tcp_tos+0x80>
     d38:	0f b7 73 02          	movzwl 0x2(%rbx),%esi
     d3c:	66 85 f6             	test   %si,%si
     d3f:	74 df                	je     d20 <tcp_tos+0x30>
     d41:	41 0f b7 4c 24 52    	movzwl 0x52(%r12),%ecx
     d47:	41 ff d6             	call   *%r14
     d4a:	66 39 c6             	cmp    %ax,%si
     d4d:	75 d1                	jne    d20 <tcp_tos+0x30>
     d4f:	49 8b 44 24 30       	mov    0x30(%r12),%rax
     d54:	80 b8 90 17 00 00 00 	cmpb   $0x0,0x1790(%rax)
     d5b:	74 13                	je     d70 <tcp_tos+0x80>
     d5d:	48 8d 44 6d 00       	lea    0x0(%rbp,%rbp,2),%rax
     d62:	41 0f b6 44 45 05    	movzbl 0x5(%r13,%rax,2),%eax
     d68:	41 88 84 24 51 01 00 	mov    %al,0x151(%r12)
     d6f:	00 
     d70:	89 f8                	mov    %edi,%eax
     d72:	48 83 c4 20          	add    $0x20,%rsp
     d76:	5b                   	pop    %rbx
     d77:	5e                   	pop    %rsi
     d78:	5f                   	pop    %rdi
     d79:	5d                   	pop    %rbp
     d7a:	41 5c                	pop    %r12
     d7c:	41 5d                	pop    %r13
     d7e:	41 5e                	pop    %r14
     d80:	31 c9                	xor    %ecx,%ecx
     d82:	c3                   	ret
     d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     d88:	41 0f b7 8c 24 d2 00 	movzwl 0xd2(%r12),%ecx
     d8f:	00 00 
     d91:	41 ff d6             	call   *%r14
     d94:	66 39 c6             	cmp    %ax,%si
     d97:	75 8f                	jne    d28 <tcp_tos+0x38>
     d99:	49 8b 44 24 30       	mov    0x30(%r12),%rax
     d9e:	80 b8 90 17 00 00 00 	cmpb   $0x0,0x1790(%rax)
     da5:	75 b6                	jne    d5d <tcp_tos+0x6d>
     da7:	eb c7                	jmp    d70 <tcp_tos+0x80>
     da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000000db0 <tcp_connect>:
     db0:	55                   	push   %rbp
     db1:	57                   	push   %rdi
     db2:	56                   	push   %rsi
     db3:	53                   	push   %rbx
     db4:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
     dbb:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # dc2 <tcp_connect+0x12>
			dbe: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     dc2:	66 0f ef c0          	pxor   %xmm0,%xmm0
     dc6:	45 31 c0             	xor    %r8d,%r8d
     dc9:	48 8b 69 30          	mov    0x30(%rcx),%rbp
     dcd:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
     dd4:	00 
     dd5:	48 89 ce             	mov    %rcx,%rsi
     dd8:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
     ddf:	00 
     de0:	c6 84 24 a0 00 00 00 	movb   $0x0,0xa0(%rsp)
     de7:	00 
     de8:	c7 44 24 5a 00 00 00 	movl   $0x0,0x5a(%rsp)
     def:	00 
     df0:	66 44 89 44 24 5e    	mov    %r8w,0x5e(%rsp)
     df6:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
     dfd:	00 
     dfe:	0f 11 84 24 c0 00 00 	movups %xmm0,0xc0(%rsp)
     e05:	00 
     e06:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
     e0d:	00 
     e0e:	0f 11 84 24 e0 00 00 	movups %xmm0,0xe0(%rsp)
     e15:	00 
     e16:	0f 11 84 24 f0 00 00 	movups %xmm0,0xf0(%rsp)
     e1d:	00 
     e1e:	0f 11 84 24 00 01 00 	movups %xmm0,0x100(%rsp)
     e25:	00 
     e26:	0f 11 84 24 10 01 00 	movups %xmm0,0x110(%rsp)
     e2d:	00 
     e2e:	0f 11 84 24 20 01 00 	movups %xmm0,0x120(%rsp)
     e35:	00 
     e36:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
     e3b:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     e40:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
     e47:	00 
     e48:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
     e4f:	00 
     e50:	f6 03 01             	testb  $0x1,(%rbx)
     e53:	0f 85 67 02 00 00    	jne    10c0 <tcp_connect+0x310>
     e59:	0f b7 86 d0 00 00 00 	movzwl 0xd0(%rsi),%eax
     e60:	66 83 f8 02          	cmp    $0x2,%ax
     e64:	0f 84 46 02 00 00    	je     10b0 <tcp_connect+0x300>
     e6a:	66 83 f8 17          	cmp    $0x17,%ax
     e6e:	0f 85 6e 04 00 00    	jne    12e2 <tcp_connect+0x532>
     e74:	ba 1c 00 00 00       	mov    $0x1c,%edx
     e79:	48 8d 7c 24 5a       	lea    0x5a(%rsp),%rdi
     e7e:	89 54 24 4c          	mov    %edx,0x4c(%rsp)
     e82:	48 8d 8e d0 00 00 00 	lea    0xd0(%rsi),%rcx
     e89:	41 b9 41 00 00 00    	mov    $0x41,%r9d
     e8f:	c7 44 24 30 0a 00 00 	movl   $0xa,0x30(%rsp)
     e96:	00 
     e97:	4c 8d 44 24 60       	lea    0x60(%rsp),%r8
     e9c:	c7 44 24 28 06 00 00 	movl   $0x6,0x28(%rsp)
     ea3:	00 
     ea4:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
     ea9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # eaf <tcp_connect+0xff>
			eab: IMAGE_REL_AMD64_REL32	__imp_getnameinfo
     eaf:	85 c0                	test   %eax,%eax
     eb1:	0f 85 73 04 00 00    	jne    132a <tcp_connect+0x57a>
     eb7:	f6 03 01             	testb  $0x1,(%rbx)
     eba:	0f 85 30 03 00 00    	jne    11f0 <tcp_connect+0x440>
     ec0:	44 8b 8e 54 01 00 00 	mov    0x154(%rsi),%r9d
     ec7:	41 f7 c1 00 10 00 00 	test   $0x1000,%r9d
     ece:	0f 85 34 02 00 00    	jne    1108 <tcp_connect+0x358>
     ed4:	41 81 e1 00 02 00 00 	and    $0x200,%r9d
     edb:	48 89 f3             	mov    %rsi,%rbx
     ede:	0f 84 4b 02 00 00    	je     112f <tcp_connect+0x37f>
     ee4:	48 8b 8b 58 01 00 00 	mov    0x158(%rbx),%rcx
     eeb:	31 d2                	xor    %edx,%edx
     eed:	e8 00 00 00 00       	call   ef2 <tcp_connect+0x142>
			eee: IMAGE_REL_AMD64_REL32	tcp_mss
     ef2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
     ef6:	48 8d 94 24 b0 00 00 	lea    0xb0(%rsp),%rdx
     efd:	00 
     efe:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
     f03:	c7 44 24 4c 80 00 00 	movl   $0x80,0x4c(%rsp)
     f0a:	00 
     f0b:	e8 00 00 00 00       	call   f10 <tcp_connect+0x160>
			f0c: IMAGE_REL_AMD64_REL32	slirp_accept_wrap
     f10:	48 89 c7             	mov    %rax,%rdi
     f13:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
     f17:	0f 84 2f 03 00 00    	je     124c <tcp_connect+0x49c>
     f1d:	48 89 43 10          	mov    %rax,0x10(%rbx)
     f21:	48 89 c1             	mov    %rax,%rcx
     f24:	e8 00 00 00 00       	call   f29 <tcp_connect+0x179>
			f25: IMAGE_REL_AMD64_REL32	slirp_set_nonblock
     f29:	48 89 d9             	mov    %rbx,%rcx
     f2c:	e8 00 00 00 00       	call   f31 <tcp_connect+0x181>
			f2d: IMAGE_REL_AMD64_REL32	slirp_register_poll_socket
     f31:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
     f38:	00 
     f39:	4c 8d 4c 24 50       	lea    0x50(%rsp),%r9
     f3e:	48 89 f9             	mov    %rdi,%rcx
     f41:	41 b8 00 01 00 00    	mov    $0x100,%r8d
     f47:	ba ff ff 00 00       	mov    $0xffff,%edx
     f4c:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
     f53:	00 
     f54:	e8 00 00 00 00       	call   f59 <tcp_connect+0x1a9>
			f55: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
     f59:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
     f60:	00 
     f61:	4c 8d 4c 24 54       	lea    0x54(%rsp),%r9
     f66:	48 89 f9             	mov    %rdi,%rcx
     f69:	41 b8 01 00 00 00    	mov    $0x1,%r8d
     f6f:	ba 06 00 00 00       	mov    $0x6,%edx
     f74:	c7 44 24 54 01 00 00 	movl   $0x1,0x54(%rsp)
     f7b:	00 
     f7c:	e8 00 00 00 00       	call   f81 <tcp_connect+0x1d1>
			f7d: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
     f81:	48 89 d9             	mov    %rbx,%rcx
     f84:	f3 0f 6f 84 24 b0 00 	movdqu 0xb0(%rsp),%xmm0
     f8b:	00 00 
     f8d:	0f 11 43 50          	movups %xmm0,0x50(%rbx)
     f91:	f3 0f 6f 84 24 c0 00 	movdqu 0xc0(%rsp),%xmm0
     f98:	00 00 
     f9a:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
     f9e:	f3 0f 6f 84 24 d0 00 	movdqu 0xd0(%rsp),%xmm0
     fa5:	00 00 
     fa7:	0f 11 43 70          	movups %xmm0,0x70(%rbx)
     fab:	f3 0f 6f 84 24 e0 00 	movdqu 0xe0(%rsp),%xmm0
     fb2:	00 00 
     fb4:	0f 11 83 80 00 00 00 	movups %xmm0,0x80(%rbx)
     fbb:	f3 0f 6f 84 24 f0 00 	movdqu 0xf0(%rsp),%xmm0
     fc2:	00 00 
     fc4:	0f 11 83 90 00 00 00 	movups %xmm0,0x90(%rbx)
     fcb:	f3 0f 6f 84 24 00 01 	movdqu 0x100(%rsp),%xmm0
     fd2:	00 00 
     fd4:	0f 11 83 a0 00 00 00 	movups %xmm0,0xa0(%rbx)
     fdb:	f3 0f 6f 84 24 10 01 	movdqu 0x110(%rsp),%xmm0
     fe2:	00 00 
     fe4:	0f 11 83 b0 00 00 00 	movups %xmm0,0xb0(%rbx)
     feb:	f3 0f 6f 84 24 20 01 	movdqu 0x120(%rsp),%xmm0
     ff2:	00 00 
     ff4:	0f 11 83 c0 00 00 00 	movups %xmm0,0xc0(%rbx)
     ffb:	e8 00 00 00 00       	call   1000 <tcp_connect+0x250>
			ffc: IMAGE_REL_AMD64_REL32	sotranslate_accept
    1000:	8b 86 54 01 00 00    	mov    0x154(%rsi),%eax
    1006:	f6 c4 10             	test   $0x10,%ah
    1009:	0f 85 31 02 00 00    	jne    1240 <tcp_connect+0x490>
    100f:	f6 c4 02             	test   $0x2,%ah
    1012:	0f 85 60 02 00 00    	jne    1278 <tcp_connect+0x4c8>
    1018:	8b 83 54 01 00 00    	mov    0x154(%rbx),%eax
    101e:	80 cc 20             	or     $0x20,%ah
    1021:	89 83 54 01 00 00    	mov    %eax,0x154(%rbx)
    1027:	48 89 d9             	mov    %rbx,%rcx
    102a:	e8 c1 fc ff ff       	call   cf0 <tcp_tos>
    102f:	88 83 50 01 00 00    	mov    %al,0x150(%rbx)
    1035:	48 8b 9b 58 01 00 00 	mov    0x158(%rbx),%rbx
    103c:	48 89 d9             	mov    %rbx,%rcx
    103f:	e8 ec ef ff ff       	call   30 <tcp_template>
    1044:	b8 02 00 00 00       	mov    $0x2,%eax
    1049:	ba 96 00 00 00       	mov    $0x96,%edx
    104e:	48 89 d9             	mov    %rbx,%rcx
    1051:	66 89 43 10          	mov    %ax,0x10(%rbx)
    1055:	66 89 53 16          	mov    %dx,0x16(%rbx)
    1059:	8b 85 78 03 00 00    	mov    0x378(%rbp),%eax
    105f:	89 83 8c 00 00 00    	mov    %eax,0x8c(%rbx)
    1065:	05 00 fa 00 00       	add    $0xfa00,%eax
    106a:	89 85 78 03 00 00    	mov    %eax,0x378(%rbp)
    1070:	8b 83 8c 00 00 00    	mov    0x8c(%rbx),%eax
    1076:	66 0f 6e c8          	movd   %eax,%xmm1
    107a:	89 83 80 00 00 00    	mov    %eax,0x80(%rbx)
    1080:	89 83 a8 00 00 00    	mov    %eax,0xa8(%rbx)
    1086:	66 0f 70 c1 e0       	pshufd $0xe0,%xmm1,%xmm0
    108b:	66 0f d6 43 78       	movq   %xmm0,0x78(%rbx)
    1090:	e8 00 00 00 00       	call   1095 <tcp_connect+0x2e5>
			1091: IMAGE_REL_AMD64_REL32	tcp_output
    1095:	90                   	nop
    1096:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    109d:	5b                   	pop    %rbx
    109e:	5e                   	pop    %rsi
    109f:	5f                   	pop    %rdi
    10a0:	5d                   	pop    %rbp
    10a1:	31 c0                	xor    %eax,%eax
    10a3:	31 d2                	xor    %edx,%edx
    10a5:	31 c9                	xor    %ecx,%ecx
    10a7:	45 31 c0             	xor    %r8d,%r8d
    10aa:	45 31 c9             	xor    %r9d,%r9d
    10ad:	c3                   	ret
    10ae:	66 90                	xchg   %ax,%ax
    10b0:	ba 10 00 00 00       	mov    $0x10,%edx
    10b5:	e9 bf fd ff ff       	jmp    e79 <tcp_connect+0xc9>
    10ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10c0:	4c 8d 05 08 01 00 00 	lea    0x108(%rip),%r8        # 11cf <tcp_connect+0x41f>
			10c3: IMAGE_REL_AMD64_REL32	.rdata
    10c7:	ba 80 00 00 00       	mov    $0x80,%edx
    10cc:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 10fd <tcp_connect+0x34d>
			10cf: IMAGE_REL_AMD64_REL32	.rdata
    10d3:	e8 00 00 00 00       	call   10d8 <tcp_connect+0x328>
			10d4: IMAGE_REL_AMD64_REL32	g_log
    10d8:	f6 03 01             	testb  $0x1,(%rbx)
    10db:	0f 84 78 fd ff ff    	je     e59 <tcp_connect+0xa9>
    10e1:	49 89 f1             	mov    %rsi,%r9
    10e4:	4c 8d 05 17 01 00 00 	lea    0x117(%rip),%r8        # 1202 <tcp_connect+0x452>
			10e7: IMAGE_REL_AMD64_REL32	.rdata
    10eb:	ba 80 00 00 00       	mov    $0x80,%edx
    10f0:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 1121 <tcp_connect+0x371>
			10f3: IMAGE_REL_AMD64_REL32	.rdata
    10f7:	e8 00 00 00 00       	call   10fc <tcp_connect+0x34c>
			10f8: IMAGE_REL_AMD64_REL32	g_log
    10fc:	e9 58 fd ff ff       	jmp    e59 <tcp_connect+0xa9>
    1101:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1108:	48 89 f1             	mov    %rsi,%rcx
    110b:	e8 00 00 00 00       	call   1110 <tcp_connect+0x360>
			110c: IMAGE_REL_AMD64_REL32	soassign_guest_addr_if_needed
    1110:	85 c0                	test   %eax,%eax
    1112:	0f 88 90 01 00 00    	js     12a8 <tcp_connect+0x4f8>
    1118:	44 8b 8e 54 01 00 00 	mov    0x154(%rsi),%r9d
    111f:	48 89 f3             	mov    %rsi,%rbx
    1122:	41 81 e1 00 02 00 00 	and    $0x200,%r9d
    1129:	0f 85 b5 fd ff ff    	jne    ee4 <tcp_connect+0x134>
    112f:	ba 06 00 00 00       	mov    $0x6,%edx
    1134:	48 89 e9             	mov    %rbp,%rcx
    1137:	e8 00 00 00 00       	call   113c <tcp_connect+0x38c>
			1138: IMAGE_REL_AMD64_REL32	socreate
    113c:	48 89 c1             	mov    %rax,%rcx
    113f:	48 89 c3             	mov    %rax,%rbx
    1142:	e8 a9 f4 ff ff       	call   5f0 <tcp_newtcpcb>
    1147:	48 89 d9             	mov    %rbx,%rcx
    114a:	48 89 83 58 01 00 00 	mov    %rax,0x158(%rbx)
    1151:	48 8b 43 30          	mov    0x30(%rbx),%rax
    1155:	48 8d 90 c0 01 00 00 	lea    0x1c0(%rax),%rdx
    115c:	e8 00 00 00 00       	call   1161 <tcp_connect+0x3b1>
			115d: IMAGE_REL_AMD64_REL32	slirp_insque
    1161:	f3 0f 6f 86 d0 00 00 	movdqu 0xd0(%rsi),%xmm0
    1168:	00 
    1169:	0f 11 83 d0 00 00 00 	movups %xmm0,0xd0(%rbx)
    1170:	f3 0f 6f 86 e0 00 00 	movdqu 0xe0(%rsi),%xmm0
    1177:	00 
    1178:	0f 11 83 e0 00 00 00 	movups %xmm0,0xe0(%rbx)
    117f:	f3 0f 6f 86 f0 00 00 	movdqu 0xf0(%rsi),%xmm0
    1186:	00 
    1187:	0f 11 83 f0 00 00 00 	movups %xmm0,0xf0(%rbx)
    118e:	f3 0f 6f 86 00 01 00 	movdqu 0x100(%rsi),%xmm0
    1195:	00 
    1196:	0f 11 83 00 01 00 00 	movups %xmm0,0x100(%rbx)
    119d:	f3 0f 6f 86 10 01 00 	movdqu 0x110(%rsi),%xmm0
    11a4:	00 
    11a5:	0f 11 83 10 01 00 00 	movups %xmm0,0x110(%rbx)
    11ac:	f3 0f 6f 86 20 01 00 	movdqu 0x120(%rsi),%xmm0
    11b3:	00 
    11b4:	0f 11 83 20 01 00 00 	movups %xmm0,0x120(%rbx)
    11bb:	f3 0f 6f 86 30 01 00 	movdqu 0x130(%rsi),%xmm0
    11c2:	00 
    11c3:	0f 11 83 30 01 00 00 	movups %xmm0,0x130(%rbx)
    11ca:	f3 0f 6f 86 40 01 00 	movdqu 0x140(%rsi),%xmm0
    11d1:	00 
    11d2:	0f 11 83 40 01 00 00 	movups %xmm0,0x140(%rbx)
    11d9:	0f b7 46 50          	movzwl 0x50(%rsi),%eax
    11dd:	66 89 43 50          	mov    %ax,0x50(%rbx)
    11e1:	e9 fe fc ff ff       	jmp    ee4 <tcp_connect+0x134>
    11e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    11ed:	00 00 00 
    11f0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    11f5:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    11fa:	4c 8d 05 2b 01 00 00 	lea    0x12b(%rip),%r8        # 132c <tcp_connect+0x57c>
			11fd: IMAGE_REL_AMD64_REL32	.rdata
    1201:	ba 80 00 00 00       	mov    $0x80,%edx
    1206:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 1237 <tcp_connect+0x487>
			1209: IMAGE_REL_AMD64_REL32	.rdata
    120d:	e8 00 00 00 00       	call   1212 <tcp_connect+0x462>
			120e: IMAGE_REL_AMD64_REL32	g_log
    1212:	44 8b 8e 54 01 00 00 	mov    0x154(%rsi),%r9d
    1219:	f6 03 01             	testb  $0x1,(%rbx)
    121c:	0f 84 a5 fc ff ff    	je     ec7 <tcp_connect+0x117>
    1222:	4c 8d 05 39 01 00 00 	lea    0x139(%rip),%r8        # 1362 <tcp_emu+0x2>
			1225: IMAGE_REL_AMD64_REL32	.rdata
    1229:	ba 80 00 00 00       	mov    $0x80,%edx
    122e:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 125f <tcp_connect+0x4af>
			1231: IMAGE_REL_AMD64_REL32	.rdata
    1235:	e8 00 00 00 00       	call   123a <tcp_connect+0x48a>
			1236: IMAGE_REL_AMD64_REL32	g_log
    123a:	e9 81 fc ff ff       	jmp    ec0 <tcp_connect+0x110>
    123f:	90                   	nop
    1240:	48 89 d9             	mov    %rbx,%rcx
    1243:	e8 00 00 00 00       	call   1248 <tcp_connect+0x498>
			1244: IMAGE_REL_AMD64_REL32	slirp_hostfwd_port_acquire
    1248:	84 c0                	test   %al,%al
    124a:	75 4c                	jne    1298 <tcp_connect+0x4e8>
    124c:	48 8b 8b 58 01 00 00 	mov    0x158(%rbx),%rcx
    1253:	e8 48 f4 ff ff       	call   6a0 <tcp_close>
    1258:	90                   	nop
    1259:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    1260:	5b                   	pop    %rbx
    1261:	5e                   	pop    %rsi
    1262:	5f                   	pop    %rdi
    1263:	5d                   	pop    %rbp
    1264:	31 c0                	xor    %eax,%eax
    1266:	31 d2                	xor    %edx,%edx
    1268:	31 c9                	xor    %ecx,%ecx
    126a:	45 31 c0             	xor    %r8d,%r8d
    126d:	45 31 c9             	xor    %r9d,%r9d
    1270:	c3                   	ret
    1271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1278:	48 89 d9             	mov    %rbx,%rcx
    127b:	e8 00 00 00 00       	call   1280 <tcp_connect+0x4d0>
			127c: IMAGE_REL_AMD64_REL32	slirp_unregister_poll_socket
    1280:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    1284:	e8 00 00 00 00       	call   1289 <tcp_connect+0x4d9>
			1285: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
    1289:	b8 01 20 00 00       	mov    $0x2001,%eax
    128e:	e9 8e fd ff ff       	jmp    1021 <tcp_connect+0x271>
    1293:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1298:	8b 86 54 01 00 00    	mov    0x154(%rsi),%eax
    129e:	e9 6c fd ff ff       	jmp    100f <tcp_connect+0x25f>
    12a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    12a8:	f6 03 02             	testb  $0x2,(%rbx)
    12ab:	75 63                	jne    1310 <tcp_connect+0x560>
    12ad:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    12b1:	48 8d 94 24 b0 00 00 	lea    0xb0(%rsp),%rdx
    12b8:	00 
    12b9:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
    12be:	c7 44 24 4c 80 00 00 	movl   $0x80,0x4c(%rsp)
    12c5:	00 
    12c6:	e8 00 00 00 00       	call   12cb <tcp_connect+0x51b>
			12c7: IMAGE_REL_AMD64_REL32	slirp_accept_wrap
    12cb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    12cf:	0f 84 c1 fd ff ff    	je     1096 <tcp_connect+0x2e6>
    12d5:	48 89 c1             	mov    %rax,%rcx
    12d8:	e8 00 00 00 00       	call   12dd <tcp_connect+0x52d>
			12d9: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
    12dd:	e9 b4 fd ff ff       	jmp    1096 <tcp_connect+0x2e6>
    12e2:	31 c9                	xor    %ecx,%ecx
    12e4:	4c 8d 0d 60 03 00 00 	lea    0x360(%rip),%r9        # 164b <tcp_emu+0x2eb>
			12e7: IMAGE_REL_AMD64_REL32	.rdata
    12eb:	41 b8 dc 01 00 00    	mov    $0x1dc,%r8d
    12f1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    12f6:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 12fd <tcp_connect+0x54d>
			12f9: IMAGE_REL_AMD64_REL32	.rdata
    12fd:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 132e <tcp_connect+0x57e>
			1300: IMAGE_REL_AMD64_REL32	.rdata
    1304:	e8 00 00 00 00       	call   1309 <tcp_connect+0x559>
			1305: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    1309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1310:	4c 8d 05 50 01 00 00 	lea    0x150(%rip),%r8        # 1467 <tcp_emu+0x107>
			1313: IMAGE_REL_AMD64_REL32	.rdata
    1317:	ba 80 00 00 00       	mov    $0x80,%edx
    131c:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 134d <tcp_connect+0x59d>
			131f: IMAGE_REL_AMD64_REL32	.rdata
    1323:	e8 00 00 00 00       	call   1328 <tcp_connect+0x578>
			1324: IMAGE_REL_AMD64_REL32	g_log
    1328:	eb 83                	jmp    12ad <tcp_connect+0x4fd>
    132a:	48 8d 05 22 01 00 00 	lea    0x122(%rip),%rax        # 1453 <tcp_emu+0xf3>
			132d: IMAGE_REL_AMD64_REL32	.rdata
    1331:	4c 8d 0d 60 03 00 00 	lea    0x360(%rip),%r9        # 1698 <tcp_emu+0x338>
			1334: IMAGE_REL_AMD64_REL32	.rdata
    1338:	41 b8 df 01 00 00    	mov    $0x1df,%r8d
    133e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1343:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 134a <tcp_connect+0x59a>
			1346: IMAGE_REL_AMD64_REL32	.rdata
    134a:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 137b <tcp_emu+0x1b>
			134d: IMAGE_REL_AMD64_REL32	.rdata
    1351:	e8 00 00 00 00       	call   1356 <tcp_connect+0x5a6>
			1352: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    1356:	90                   	nop
    1357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    135e:	00 00 

0000000000001360 <tcp_emu>:
    1360:	41 56                	push   %r14
    1362:	41 55                	push   %r13
    1364:	41 54                	push   %r12
    1366:	55                   	push   %rbp
    1367:	57                   	push   %rdi
    1368:	56                   	push   %rsi
    1369:	53                   	push   %rbx
    136a:	48 81 ec a0 01 00 00 	sub    $0x1a0,%rsp
    1371:	41 b8 01 01 00 00    	mov    $0x101,%r8d
    1377:	48 8b 79 30          	mov    0x30(%rcx),%rdi
    137b:	48 89 cb             	mov    %rcx,%rbx
    137e:	48 89 d6             	mov    %rdx,%rsi
    1381:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
    1388:	00 
    1389:	31 d2                	xor    %edx,%edx
    138b:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
    1392:	00 
    1393:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
    139a:	00 
    139b:	c7 44 24 64 00 00 00 	movl   $0x0,0x64(%rsp)
    13a2:	00 
    13a3:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
    13aa:	00 
    13ab:	c7 44 24 6c 00 00 00 	movl   $0x0,0x6c(%rsp)
    13b2:	00 
    13b3:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
    13ba:	00 
    13bb:	e8 00 00 00 00       	call   13c0 <tcp_emu+0x60>
			13bc: IMAGE_REL_AMD64_REL32	memset
    13c0:	48 8b 2d 00 00 00 00 	mov    0x0(%rip),%rbp        # 13c7 <tcp_emu+0x67>
			13c3: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    13c7:	c7 44 24 74 00 00 00 	movl   $0x0,0x74(%rsp)
    13ce:	00 
    13cf:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
    13d6:	00 
    13d7:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
    13db:	75 2b                	jne    1408 <tcp_emu+0xa8>
    13dd:	80 bb 51 01 00 00 07 	cmpb   $0x7,0x151(%rbx)
    13e4:	0f 87 16 07 00 00    	ja     1b00 <tcp_emu+0x7a0>
    13ea:	0f b6 83 51 01 00 00 	movzbl 0x151(%rbx),%eax
    13f1:	48 8d 15 e0 02 00 00 	lea    0x2e0(%rip),%rdx        # 16d8 <tcp_emu+0x378>
			13f4: IMAGE_REL_AMD64_REL32	.rdata
    13f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    13fc:	48 63 04 82          	movslq (%rdx,%rax,4),%rax
    1400:	48 01 d0             	add    %rdx,%rax
    1403:	ff e0                	jmp    *%rax
    1405:	0f 1f 00             	nopl   (%rax)
    1408:	4c 8d 05 72 01 00 00 	lea    0x172(%rip),%r8        # 1581 <tcp_emu+0x221>
			140b: IMAGE_REL_AMD64_REL32	.rdata
    140f:	ba 80 00 00 00       	mov    $0x80,%edx
    1414:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 1445 <tcp_emu+0xe5>
			1417: IMAGE_REL_AMD64_REL32	.rdata
    141b:	e8 00 00 00 00       	call   1420 <tcp_emu+0xc0>
			141c: IMAGE_REL_AMD64_REL32	g_log
    1420:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
    1424:	74 b7                	je     13dd <tcp_emu+0x7d>
    1426:	49 89 d9             	mov    %rbx,%r9
    1429:	4c 8d 05 c0 00 00 00 	lea    0xc0(%rip),%r8        # 14f0 <tcp_emu+0x190>
			142c: IMAGE_REL_AMD64_REL32	.rdata
    1430:	ba 80 00 00 00       	mov    $0x80,%edx
    1435:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 1466 <tcp_emu+0x106>
			1438: IMAGE_REL_AMD64_REL32	.rdata
    143c:	e8 00 00 00 00       	call   1441 <tcp_emu+0xe1>
			143d: IMAGE_REL_AMD64_REL32	g_log
    1441:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
    1445:	74 96                	je     13dd <tcp_emu+0x7d>
    1447:	49 89 f1             	mov    %rsi,%r9
    144a:	4c 8d 05 51 00 00 00 	lea    0x51(%rip),%r8        # 14a2 <tcp_emu+0x142>
			144d: IMAGE_REL_AMD64_REL32	.rdata
    1451:	ba 80 00 00 00       	mov    $0x80,%edx
    1456:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 1487 <tcp_emu+0x127>
			1459: IMAGE_REL_AMD64_REL32	.rdata
    145d:	e8 00 00 00 00       	call   1462 <tcp_emu+0x102>
			145e: IMAGE_REL_AMD64_REL32	g_log
    1462:	e9 76 ff ff ff       	jmp    13dd <tcp_emu+0x7d>
    1467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    146e:	00 00 
    1470:	48 63 56 38          	movslq 0x38(%rsi),%rdx
    1474:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    1478:	4c 8d 05 7d 01 00 00 	lea    0x17d(%rip),%r8        # 15fc <tcp_emu+0x29c>
			147b: IMAGE_REL_AMD64_REL32	.rdata
    147f:	c7 44 24 7c 10 00 00 	movl   $0x10,0x7c(%rsp)
    1486:	00 
    1487:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    148e:	00 
    148f:	e8 00 00 00 00       	call   1494 <tcp_emu+0x134>
			1490: IMAGE_REL_AMD64_REL32	g_strstr_len
    1494:	48 89 c5             	mov    %rax,%rbp
    1497:	48 85 c0             	test   %rax,%rax
    149a:	74 2a                	je     14c6 <tcp_emu+0x166>
    149c:	c6 00 00             	movb   $0x0,(%rax)
    149f:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    14a3:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    14a8:	4c 8d 44 24 5c       	lea    0x5c(%rsp),%r8
    14ad:	48 8d 15 80 01 00 00 	lea    0x180(%rip),%rdx        # 1634 <tcp_emu+0x2d4>
			14b0: IMAGE_REL_AMD64_REL32	.rdata
    14b4:	e8 00 00 00 00       	call   14b9 <tcp_emu+0x159>
			14b5: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    14b9:	83 f8 02             	cmp    $0x2,%eax
    14bc:	0f 84 de 09 00 00    	je     1ea0 <tcp_emu+0xb40>
    14c2:	c6 45 00 0d          	movb   $0xd,0x0(%rbp)
    14c6:	b8 01 00 00 00       	mov    $0x1,%eax
    14cb:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
    14d2:	5b                   	pop    %rbx
    14d3:	5e                   	pop    %rsi
    14d4:	5f                   	pop    %rdi
    14d5:	5d                   	pop    %rbp
    14d6:	41 5c                	pop    %r12
    14d8:	41 5d                	pop    %r13
    14da:	41 5e                	pop    %r14
    14dc:	31 d2                	xor    %edx,%edx
    14de:	31 c9                	xor    %ecx,%ecx
    14e0:	45 31 c0             	xor    %r8d,%r8d
    14e3:	45 31 c9             	xor    %r9d,%r9d
    14e6:	45 31 d2             	xor    %r10d,%r10d
    14e9:	45 31 db             	xor    %r11d,%r11d
    14ec:	c3                   	ret
    14ed:	0f 1f 00             	nopl   (%rax)
    14f0:	8b 46 38             	mov    0x38(%rsi),%eax
    14f3:	48 89 f1             	mov    %rsi,%rcx
    14f6:	8d 50 01             	lea    0x1(%rax),%edx
    14f9:	e8 00 00 00 00       	call   14fe <tcp_emu+0x19e>
			14fa: IMAGE_REL_AMD64_REL32	m_inc
    14fe:	48 63 46 38          	movslq 0x38(%rsi),%rax
    1502:	48 8b 56 30          	mov    0x30(%rsi),%rdx
    1506:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    150a:	4c 8b 66 30          	mov    0x30(%rsi),%r12
    150e:	48 8d 15 93 01 00 00 	lea    0x193(%rip),%rdx        # 16a8 <tcp_emu+0x348>
			1511: IMAGE_REL_AMD64_REL32	.rdata
    1515:	4c 89 e1             	mov    %r12,%rcx
    1518:	e8 00 00 00 00       	call   151d <tcp_emu+0x1bd>
			1519: IMAGE_REL_AMD64_REL32	strstr
    151d:	48 89 c5             	mov    %rax,%rbp
    1520:	48 85 c0             	test   %rax,%rax
    1523:	0f 84 17 06 00 00    	je     1b40 <tcp_emu+0x7e0>
    1529:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    1530:	00 
    1531:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    1536:	48 89 e9             	mov    %rbp,%rcx
    1539:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    153e:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    1543:	4c 8d 44 24 5c       	lea    0x5c(%rsp),%r8
    1548:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    154d:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    1552:	48 8d 15 98 01 00 00 	lea    0x198(%rip),%rdx        # 16f1 <tcp_emu+0x391>
			1555: IMAGE_REL_AMD64_REL32	.rdata
    1559:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    155e:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
    1563:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    1568:	48 8d 44 24 64       	lea    0x64(%rsp),%rax
    156d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1572:	e8 00 00 00 00       	call   1577 <tcp_emu+0x217>
			1573: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    1577:	41 89 c4             	mov    %eax,%r12d
    157a:	83 f8 05             	cmp    $0x5,%eax
    157d:	0f 8e 43 ff ff ff    	jle    14c6 <tcp_emu+0x166>
    1583:	8b 4c 24 5c          	mov    0x5c(%rsp),%ecx
    1587:	8b 44 24 60          	mov    0x60(%rsp),%eax
    158b:	c1 e1 18             	shl    $0x18,%ecx
    158e:	c1 e0 10             	shl    $0x10,%eax
    1591:	09 c1                	or     %eax,%ecx
    1593:	8b 44 24 64          	mov    0x64(%rsp),%eax
    1597:	0b 4c 24 68          	or     0x68(%rsp),%ecx
    159b:	c1 e0 08             	shl    $0x8,%eax
    159e:	09 c1                	or     %eax,%ecx
    15a0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 15a6 <tcp_emu+0x246>
			15a2: IMAGE_REL_AMD64_REL32	__imp_htonl
    15a6:	0f b7 4c 24 6c       	movzwl 0x6c(%rsp),%ecx
    15ab:	89 44 24 74          	mov    %eax,0x74(%rsp)
    15af:	c1 e1 08             	shl    $0x8,%ecx
    15b2:	66 0b 4c 24 70       	or     0x70(%rsp),%cx
    15b7:	0f b7 c9             	movzwl %cx,%ecx
    15ba:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 15c0 <tcp_emu+0x260>
			15bc: IMAGE_REL_AMD64_REL32	__imp_htons
    15c0:	44 8b 4c 24 74       	mov    0x74(%rsp),%r9d
    15c5:	45 31 c0             	xor    %r8d,%r8d
    15c8:	31 d2                	xor    %edx,%edx
    15ca:	0f b7 c0             	movzwl %ax,%eax
    15cd:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    15d4:	00 
    15d5:	48 89 f9             	mov    %rdi,%rcx
    15d8:	89 44 24 20          	mov    %eax,0x20(%rsp)
    15dc:	89 44 24 78          	mov    %eax,0x78(%rsp)
    15e0:	e8 00 00 00 00       	call   15e5 <tcp_emu+0x285>
			15e1: IMAGE_REL_AMD64_REL32	tcp_listen
    15e5:	49 89 c5             	mov    %rax,%r13
    15e8:	48 85 c0             	test   %rax,%rax
    15eb:	0f 84 d5 fe ff ff    	je     14c6 <tcp_emu+0x166>
    15f1:	0f b7 48 52          	movzwl 0x52(%rax),%ecx
    15f5:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 15fb <tcp_emu+0x29b>
			15f7: IMAGE_REL_AMD64_REL32	__imp_ntohs
    15fb:	41 8b 4d 54          	mov    0x54(%r13),%ecx
    15ff:	3b 4f 18             	cmp    0x18(%rdi),%ecx
    1602:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1606:	0f b6 d4             	movzbl %ah,%edx
    1609:	0f b6 c0             	movzbl %al,%eax
    160c:	89 54 24 6c          	mov    %edx,0x6c(%rsp)
    1610:	89 44 24 70          	mov    %eax,0x70(%rsp)
    1614:	0f 84 21 0a 00 00    	je     203b <tcp_emu+0xcdb>
    161a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1620 <tcp_emu+0x2c0>
			161c: IMAGE_REL_AMD64_REL32	__imp_ntohl
    1620:	41 89 c0             	mov    %eax,%r8d
    1623:	4c 8b 5e 30          	mov    0x30(%rsi),%r11
    1627:	41 89 c1             	mov    %eax,%r9d
    162a:	49 89 ea             	mov    %rbp,%r10
    162d:	41 c1 e8 10          	shr    $0x10,%r8d
    1631:	41 c1 e9 18          	shr    $0x18,%r9d
    1635:	0f b6 dc             	movzbl %ah,%ebx
    1638:	0f b6 c8             	movzbl %al,%ecx
    163b:	4d 29 da             	sub    %r11,%r10
    163e:	89 44 24 74          	mov    %eax,0x74(%rsp)
    1642:	41 83 fc 07          	cmp    $0x7,%r12d
    1646:	45 0f b6 c0          	movzbl %r8b,%r8d
    164a:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
    1651:	00 
    1652:	48 8d 05 71 01 00 00 	lea    0x171(%rip),%rax        # 17ca <tcp_emu+0x46a>
			1655: IMAGE_REL_AMD64_REL32	.rdata
    1659:	44 89 4c 24 5c       	mov    %r9d,0x5c(%rsp)
    165e:	44 8b 64 24 70       	mov    0x70(%rsp),%r12d
    1663:	48 0f 44 c7          	cmove  %rdi,%rax
    1667:	44 89 44 24 60       	mov    %r8d,0x60(%rsp)
    166c:	8b 7c 24 6c          	mov    0x6c(%rsp),%edi
    1670:	89 5c 24 64          	mov    %ebx,0x64(%rsp)
    1674:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1678:	89 4c 24 68          	mov    %ecx,0x68(%rsp)
    167c:	44 89 56 38          	mov    %r10d,0x38(%rsi)
    1680:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    1684:	0f 84 8e 09 00 00    	je     2018 <tcp_emu+0xcb8>
    168a:	48 03 56 58          	add    0x58(%rsi),%rdx
    168e:	4c 29 da             	sub    %r11,%rdx
    1691:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
    1695:	4d 63 d2             	movslq %r10d,%r10
    1698:	48 89 e9             	mov    %rbp,%rcx
    169b:	44 89 44 24 20       	mov    %r8d,0x20(%rsp)
    16a0:	4c 29 d2             	sub    %r10,%rdx
    16a3:	4c 8d 05 b8 01 00 00 	lea    0x1b8(%rip),%r8        # 1862 <tcp_emu+0x502>
			16a6: IMAGE_REL_AMD64_REL32	.rdata
    16aa:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    16af:	44 89 64 24 40       	mov    %r12d,0x40(%rsp)
    16b4:	89 7c 24 38          	mov    %edi,0x38(%rsp)
    16b8:	89 5c 24 28          	mov    %ebx,0x28(%rsp)
    16bc:	e8 00 00 00 00       	call   16c1 <tcp_emu+0x361>
			16bd: IMAGE_REL_AMD64_REL32	slirp_fmt
    16c1:	01 46 38             	add    %eax,0x38(%rsi)
    16c4:	e9 fd fd ff ff       	jmp    14c6 <tcp_emu+0x166>
    16c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    16d0:	c6 83 51 01 00 00 00 	movb   $0x0,0x151(%rbx)
    16d7:	8b 56 38             	mov    0x38(%rsi),%edx
    16da:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
    16e1:	00 
    16e2:	44 8d 4a ff          	lea    -0x1(%rdx),%r9d
    16e6:	45 85 c9             	test   %r9d,%r9d
    16e9:	0f 8e d7 fd ff ff    	jle    14c6 <tcp_emu+0x166>
    16ef:	4c 8b 56 30          	mov    0x30(%rsi),%r10
    16f3:	83 ea 02             	sub    $0x2,%edx
    16f6:	31 c9                	xor    %ecx,%ecx
    16f8:	4c 89 d0             	mov    %r10,%rax
    16fb:	4d 8d 44 12 01       	lea    0x1(%r10,%rdx,1),%r8
    1700:	0f b6 10             	movzbl (%rax),%edx
    1703:	83 ea 30             	sub    $0x30,%edx
    1706:	80 fa 09             	cmp    $0x9,%dl
    1709:	0f 87 b7 fd ff ff    	ja     14c6 <tcp_emu+0x166>
    170f:	8d 14 89             	lea    (%rcx,%rcx,4),%edx
    1712:	48 83 c0 01          	add    $0x1,%rax
    1716:	01 d2                	add    %edx,%edx
    1718:	89 54 24 78          	mov    %edx,0x78(%rsp)
    171c:	0f be 48 ff          	movsbl -0x1(%rax),%ecx
    1720:	8d 4c 0a d0          	lea    -0x30(%rdx,%rcx,1),%ecx
    1724:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
    1728:	4c 39 c0             	cmp    %r8,%rax
    172b:	75 d3                	jne    1700 <tcp_emu+0x3a0>
    172d:	43 80 3c 0a 00       	cmpb   $0x0,(%r10,%r9,1)
    1732:	0f 85 8e fd ff ff    	jne    14c6 <tcp_emu+0x166>
    1738:	85 c9                	test   %ecx,%ecx
    173a:	0f 84 86 fd ff ff    	je     14c6 <tcp_emu+0x166>
    1740:	0f b7 c9             	movzwl %cx,%ecx
    1743:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1749 <tcp_emu+0x3e9>
			1745: IMAGE_REL_AMD64_REL32	__imp_htons
    1749:	45 31 c0             	xor    %r8d,%r8d
    174c:	31 d2                	xor    %edx,%edx
    174e:	48 89 f9             	mov    %rdi,%rcx
    1751:	0f b7 c0             	movzwl %ax,%eax
    1754:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    175b:	00 
    175c:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1760:	44 8b 8b d4 00 00 00 	mov    0xd4(%rbx),%r9d
    1767:	e8 00 00 00 00       	call   176c <tcp_emu+0x40c>
			1768: IMAGE_REL_AMD64_REL32	tcp_listen
    176c:	48 85 c0             	test   %rax,%rax
    176f:	0f 84 51 fd ff ff    	je     14c6 <tcp_emu+0x166>
    1775:	0f b7 48 52          	movzwl 0x52(%rax),%ecx
    1779:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 177f <tcp_emu+0x41f>
			177b: IMAGE_REL_AMD64_REL32	__imp_ntohs
    177f:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1783:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    1787:	44 0f b7 c8          	movzwl %ax,%r9d
    178b:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    178f:	0f 84 19 09 00 00    	je     20ae <tcp_emu+0xd4e>
    1795:	48 03 56 58          	add    0x58(%rsi),%rdx
    1799:	48 29 ca             	sub    %rcx,%rdx
    179c:	4c 8d 05 49 02 00 00 	lea    0x249(%rip),%r8        # 19ec <tcp_emu+0x68c>
			179f: IMAGE_REL_AMD64_REL32	.rdata
    17a3:	e8 00 00 00 00       	call   17a8 <tcp_emu+0x448>
			17a4: IMAGE_REL_AMD64_REL32	slirp_fmt0
    17a8:	89 46 38             	mov    %eax,0x38(%rsi)
    17ab:	e9 16 fd ff ff       	jmp    14c6 <tcp_emu+0x166>
    17b0:	8b 46 38             	mov    0x38(%rsi),%eax
    17b3:	48 89 f1             	mov    %rsi,%rcx
    17b6:	8d 50 01             	lea    0x1(%rax),%edx
    17b9:	e8 00 00 00 00       	call   17be <tcp_emu+0x45e>
			17ba: IMAGE_REL_AMD64_REL32	m_inc
    17be:	48 63 46 38          	movslq 0x38(%rsi),%rax
    17c2:	48 8b 56 30          	mov    0x30(%rsi),%rdx
    17c6:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    17ca:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    17ce:	48 8d 15 4c 02 00 00 	lea    0x24c(%rip),%rdx        # 1a21 <tcp_emu+0x6c1>
			17d1: IMAGE_REL_AMD64_REL32	.rdata
    17d5:	e8 00 00 00 00       	call   17da <tcp_emu+0x47a>
			17d6: IMAGE_REL_AMD64_REL32	strstr
    17da:	48 89 c3             	mov    %rax,%rbx
    17dd:	48 85 c0             	test   %rax,%rax
    17e0:	0f 84 e0 fc ff ff    	je     14c6 <tcp_emu+0x166>
    17e6:	48 8d 6c 24 78       	lea    0x78(%rsp),%rbp
    17eb:	4c 8d 4c 24 74       	lea    0x74(%rsp),%r9
    17f0:	48 89 c1             	mov    %rax,%rcx
    17f3:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
    17f8:	4c 8d 84 24 90 00 00 	lea    0x90(%rsp),%r8
    17ff:	00 
    1800:	48 8d 15 50 02 00 00 	lea    0x250(%rip),%rdx        # 1a57 <tcp_emu+0x6f7>
			1803: IMAGE_REL_AMD64_REL32	.rdata
    1807:	e8 00 00 00 00       	call   180c <tcp_emu+0x4ac>
			1808: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    180c:	83 f8 03             	cmp    $0x3,%eax
    180f:	0f 84 1b 05 00 00    	je     1d30 <tcp_emu+0x9d0>
    1815:	4c 8d 64 24 5c       	lea    0x5c(%rsp),%r12
    181a:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
    181f:	4c 8d 4c 24 74       	lea    0x74(%rsp),%r9
    1824:	48 89 d9             	mov    %rbx,%rcx
    1827:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    182c:	4c 8d 84 24 90 00 00 	lea    0x90(%rsp),%r8
    1833:	00 
    1834:	48 8d 15 7d 02 00 00 	lea    0x27d(%rip),%rdx        # 1ab8 <tcp_emu+0x758>
			1837: IMAGE_REL_AMD64_REL32	.rdata
    183b:	e8 00 00 00 00       	call   1840 <tcp_emu+0x4e0>
			183c: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    1840:	83 f8 04             	cmp    $0x4,%eax
    1843:	0f 84 97 05 00 00    	je     1de0 <tcp_emu+0xa80>
    1849:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    184e:	4c 8d 4c 24 74       	lea    0x74(%rsp),%r9
    1853:	48 89 d9             	mov    %rbx,%rcx
    1856:	4c 8d 84 24 90 00 00 	lea    0x90(%rsp),%r8
    185d:	00 
    185e:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
    1863:	48 8d 15 ae 02 00 00 	lea    0x2ae(%rip),%rdx        # 1b18 <tcp_emu+0x7b8>
			1866: IMAGE_REL_AMD64_REL32	.rdata
    186a:	e8 00 00 00 00       	call   186f <tcp_emu+0x50f>
			186b: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    186f:	83 f8 04             	cmp    $0x4,%eax
    1872:	0f 85 4e fc ff ff    	jne    14c6 <tcp_emu+0x166>
    1878:	0f b7 4c 24 78       	movzwl 0x78(%rsp),%ecx
    187d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1883 <tcp_emu+0x523>
			187f: IMAGE_REL_AMD64_REL32	__imp_htons
    1883:	8b 4c 24 74          	mov    0x74(%rsp),%ecx
    1887:	0f b7 e8             	movzwl %ax,%ebp
    188a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1890 <tcp_emu+0x530>
			188c: IMAGE_REL_AMD64_REL32	__imp_htonl
    1890:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
    1894:	48 89 f9             	mov    %rdi,%rcx
    1897:	45 31 c0             	xor    %r8d,%r8d
    189a:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    18a1:	00 
    18a2:	41 89 c1             	mov    %eax,%r9d
    18a5:	31 d2                	xor    %edx,%edx
    18a7:	e8 00 00 00 00       	call   18ac <tcp_emu+0x54c>
			18a8: IMAGE_REL_AMD64_REL32	tcp_listen
    18ac:	48 89 c7             	mov    %rax,%rdi
    18af:	48 85 c0             	test   %rax,%rax
    18b2:	0f 84 0e fc ff ff    	je     14c6 <tcp_emu+0x166>
    18b8:	48 89 d8             	mov    %rbx,%rax
    18bb:	48 2b 46 30          	sub    0x30(%rsi),%rax
    18bf:	44 8b 64 24 5c       	mov    0x5c(%rsp),%r12d
    18c4:	89 46 38             	mov    %eax,0x38(%rsi)
    18c7:	0f b7 4f 52          	movzwl 0x52(%rdi),%ecx
    18cb:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 18d1 <tcp_emu+0x571>
			18cd: IMAGE_REL_AMD64_REL32	__imp_ntohs
    18d1:	8b 4f 54             	mov    0x54(%rdi),%ecx
    18d4:	0f b7 e8             	movzwl %ax,%ebp
    18d7:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 18dd <tcp_emu+0x57d>
			18d9: IMAGE_REL_AMD64_REL32	__imp_ntohl
    18dd:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    18e1:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    18e5:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    18e9:	0f 84 cc 07 00 00    	je     20bb <tcp_emu+0xd5b>
    18ef:	48 03 56 58          	add    0x58(%rsi),%rdx
    18f3:	48 29 ca             	sub    %rcx,%rdx
    18f6:	48 63 4e 38          	movslq 0x38(%rsi),%rcx
    18fa:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
    1901:	00 
    1902:	4c 8d 8c 24 90 00 00 	lea    0x90(%rsp),%r9
    1909:	00 
    190a:	4c 8d 05 c6 02 00 00 	lea    0x2c6(%rip),%r8        # 1bd7 <tcp_emu+0x877>
			190d: IMAGE_REL_AMD64_REL32	.rdata
    1911:	44 89 64 24 30       	mov    %r12d,0x30(%rsp)
    1916:	89 6c 24 28          	mov    %ebp,0x28(%rsp)
    191a:	48 29 ca             	sub    %rcx,%rdx
    191d:	48 89 d9             	mov    %rbx,%rcx
    1920:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1924:	e8 00 00 00 00       	call   1929 <tcp_emu+0x5c9>
			1925: IMAGE_REL_AMD64_REL32	slirp_fmt
    1929:	01 46 38             	add    %eax,0x38(%rsi)
    192c:	e9 95 fb ff ff       	jmp    14c6 <tcp_emu+0x166>
    1931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1938:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    193c:	4c 63 46 38          	movslq 0x38(%rsi),%r8
    1940:	4e 8d 14 01          	lea    (%rcx,%r8,1),%r10
    1944:	4c 39 d1             	cmp    %r10,%rcx
    1947:	0f 83 79 fb ff ff    	jae    14c6 <tcp_emu+0x166>
    194d:	8b 05 00 00 00 00    	mov    0x0(%rip),%eax        # 1953 <tcp_emu+0x5f3>
			194f: IMAGE_REL_AMD64_REL32	.bss
    1953:	49 89 cd             	mov    %rcx,%r13
    1956:	31 f6                	xor    %esi,%esi
    1958:	4c 8d 1d 00 03 00 00 	lea    0x300(%rip),%r11        # 1c5f <tcp_emu+0x8ff>
			195b: IMAGE_REL_AMD64_REL32	.rdata
    195f:	c7 84 24 80 00 00 00 	movl   $0x414e50,0x80(%rsp)
    1966:	50 4e 41 00 
    196a:	83 f8 06             	cmp    $0x6,%eax
    196d:	77 0c                	ja     197b <tcp_emu+0x61b>
    196f:	41 89 c1             	mov    %eax,%r9d
    1972:	4b 63 14 8b          	movslq (%r11,%r9,4),%rdx
    1976:	4c 01 da             	add    %r11,%rdx
    1979:	ff e2                	jmp    *%rdx
    197b:	4d 39 d5             	cmp    %r10,%r13
    197e:	0f 83 4e 07 00 00    	jae    20d2 <tcp_emu+0xd72>
    1984:	be 01 00 00 00       	mov    $0x1,%esi
    1989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1990:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    1995:	4c 89 ea             	mov    %r13,%rdx
    1998:	49 83 c5 01          	add    $0x1,%r13
    199c:	3c 50                	cmp    $0x50,%al
    199e:	0f 84 2c 06 00 00    	je     1fd0 <tcp_emu+0xc70>
    19a4:	3c 4e                	cmp    $0x4e,%al
    19a6:	0f 85 44 03 00 00    	jne    1cf0 <tcp_emu+0x990>
    19ac:	4d 39 d5             	cmp    %r10,%r13
    19af:	0f 83 13 07 00 00    	jae    20c8 <tcp_emu+0xd68>
    19b5:	c7 84 24 80 00 00 00 	movl   $0x414e50,0x80(%rsp)
    19bc:	50 4e 41 00 
    19c0:	b8 02 00 00 00       	mov    $0x2,%eax
    19c5:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    19cb:	4c 89 ea             	mov    %r13,%rdx
    19ce:	42 0f b6 b4 0c 80 00 	movzbl 0x80(%rsp,%r9,1),%esi
    19d5:	00 00 
    19d7:	49 83 c5 01          	add    $0x1,%r13
    19db:	40 38 32             	cmp    %sil,(%rdx)
    19de:	0f 84 3c 01 00 00    	je     1b20 <tcp_emu+0x7c0>
    19e4:	4d 39 d5             	cmp    %r10,%r13
    19e7:	0f 83 1d 03 00 00    	jae    1d0a <tcp_emu+0x9aa>
    19ed:	c7 84 24 80 00 00 00 	movl   $0x414e50,0x80(%rsp)
    19f4:	50 4e 41 00 
    19f8:	4c 89 ea             	mov    %r13,%rdx
    19fb:	31 c0                	xor    %eax,%eax
    19fd:	45 31 c9             	xor    %r9d,%r9d
    1a00:	eb cc                	jmp    19ce <tcp_emu+0x66e>
    1a02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1a08:	49 83 c5 01          	add    $0x1,%r13
    1a0c:	4d 39 d5             	cmp    %r10,%r13
    1a0f:	0f 83 87 06 00 00    	jae    209c <tcp_emu+0xd3c>
    1a15:	be 01 00 00 00       	mov    $0x1,%esi
    1a1a:	49 83 e8 01          	sub    $0x1,%r8
    1a1e:	4a 8d 04 01          	lea    (%rcx,%r8,1),%rax
    1a22:	49 39 c5             	cmp    %rax,%r13
    1a25:	0f 84 59 06 00 00    	je     2084 <tcp_emu+0xd24>
    1a2b:	41 80 7d 01 02       	cmpb   $0x2,0x1(%r13)
    1a30:	0f 84 e2 02 00 00    	je     1d18 <tcp_emu+0x9b8>
    1a36:	49 83 c5 04          	add    $0x4,%r13
    1a3a:	4d 39 d5             	cmp    %r10,%r13
    1a3d:	0f 83 e2 02 00 00    	jae    1d25 <tcp_emu+0x9c5>
    1a43:	c7 05 fc ff ff ff 06 	movl   $0x6,-0x4(%rip)        # 1a49 <tcp_emu+0x6e9>
    1a4a:	00 00 00 
			1a45: IMAGE_REL_AMD64_REL32	.bss
    1a4d:	4c 01 c1             	add    %r8,%rcx
    1a50:	49 39 cd             	cmp    %rcx,%r13
    1a53:	0f 84 6d fa ff ff    	je     14c6 <tcp_emu+0x166>
    1a59:	41 0f b7 45 00       	movzwl 0x0(%r13),%eax
    1a5e:	66 c1 c0 08          	rol    $0x8,%ax
    1a62:	0f b7 c8             	movzwl %ax,%ecx
    1a65:	66 3d 3a 1b          	cmp    $0x1b3a,%ax
    1a69:	8d 91 00 01 00 00    	lea    0x100(%rcx),%edx
    1a6f:	0f 42 ca             	cmovb  %edx,%ecx
    1a72:	8d 81 c6 e4 ff ff    	lea    -0x1b3a(%rcx),%eax
    1a78:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
    1a7c:	3d c8 00 00 00       	cmp    $0xc8,%eax
    1a81:	0f 87 3f fa ff ff    	ja     14c6 <tcp_emu+0x166>
    1a87:	4c 8b 25 00 00 00 00 	mov    0x0(%rip),%r12        # 1a8e <tcp_emu+0x72e>
			1a8a: IMAGE_REL_AMD64_REL32	__imp_htons
    1a8e:	be 3a 1b 00 00       	mov    $0x1b3a,%esi
    1a93:	eb 15                	jmp    1aaa <tcp_emu+0x74a>
    1a95:	0f 1f 00             	nopl   (%rax)
    1a98:	83 c6 01             	add    $0x1,%esi
    1a9b:	66 81 fe 9f 1b       	cmp    $0x1b9f,%si
    1aa0:	0f 84 7f 05 00 00    	je     2025 <tcp_emu+0xcc5>
    1aa6:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
    1aaa:	0f b7 c9             	movzwl %cx,%ecx
    1aad:	41 ff d4             	call   *%r12
    1ab0:	44 8b b3 d4 00 00 00 	mov    0xd4(%rbx),%r14d
    1ab7:	0f b7 ce             	movzwl %si,%ecx
    1aba:	0f b7 e8             	movzwl %ax,%ebp
    1abd:	41 ff d4             	call   *%r12
    1ac0:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    1ac7:	00 
    1ac8:	31 d2                	xor    %edx,%edx
    1aca:	45 89 f1             	mov    %r14d,%r9d
    1acd:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
    1ad1:	44 0f b7 c0          	movzwl %ax,%r8d
    1ad5:	48 89 f9             	mov    %rdi,%rcx
    1ad8:	e8 00 00 00 00       	call   1add <tcp_emu+0x77d>
			1ad9: IMAGE_REL_AMD64_REL32	udp_listen
    1add:	48 85 c0             	test   %rax,%rax
    1ae0:	74 b6                	je     1a98 <tcp_emu+0x738>
    1ae2:	b8 1b 00 00 00       	mov    $0x1b,%eax
    1ae7:	41 88 45 00          	mov    %al,0x0(%r13)
    1aeb:	41 88 75 01          	mov    %sil,0x1(%r13)
    1aef:	c7 05 fc ff ff ff 00 	movl   $0x0,-0x4(%rip)        # 1af5 <tcp_emu+0x795>
    1af6:	00 00 00 
			1af1: IMAGE_REL_AMD64_REL32	.bss
    1af9:	e9 c8 f9 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1afe:	66 90                	xchg   %ax,%ax
    1b00:	c6 83 51 01 00 00 00 	movb   $0x0,0x151(%rbx)
    1b07:	e9 ba f9 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1b0c:	49 83 e8 01          	sub    $0x1,%r8
    1b10:	40 84 f6             	test   %sil,%sil
    1b13:	0f 85 2a ff ff ff    	jne    1a43 <tcp_emu+0x6e3>
    1b19:	e9 2f ff ff ff       	jmp    1a4d <tcp_emu+0x6ed>
    1b1e:	66 90                	xchg   %ax,%ax
    1b20:	83 c0 01             	add    $0x1,%eax
    1b23:	be 01 00 00 00       	mov    $0x1,%esi
    1b28:	4d 39 d5             	cmp    %r10,%r13
    1b2b:	0f 82 2e fe ff ff    	jb     195f <tcp_emu+0x5ff>
    1b31:	89 05 00 00 00 00    	mov    %eax,0x0(%rip)        # 1b37 <tcp_emu+0x7d7>
			1b33: IMAGE_REL_AMD64_REL32	.bss
    1b37:	e9 8a f9 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1b3c:	0f 1f 40 00          	nopl   0x0(%rax)
    1b40:	48 8d 15 d2 01 00 00 	lea    0x1d2(%rip),%rdx        # 1d19 <tcp_emu+0x9b9>
			1b43: IMAGE_REL_AMD64_REL32	.rdata
    1b47:	4c 89 e1             	mov    %r12,%rcx
    1b4a:	e8 00 00 00 00       	call   1b4f <tcp_emu+0x7ef>
			1b4b: IMAGE_REL_AMD64_REL32	strstr
    1b4f:	48 89 c3             	mov    %rax,%rbx
    1b52:	48 85 c0             	test   %rax,%rax
    1b55:	0f 84 6b f9 ff ff    	je     14c6 <tcp_emu+0x166>
    1b5b:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    1b62:	00 
    1b63:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    1b68:	48 89 d9             	mov    %rbx,%rcx
    1b6b:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    1b70:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    1b75:	4c 8d 44 24 5c       	lea    0x5c(%rsp),%r8
    1b7a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    1b7f:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    1b84:	48 8d 15 e0 01 00 00 	lea    0x1e0(%rip),%rdx        # 1d6b <tcp_emu+0xa0b>
			1b87: IMAGE_REL_AMD64_REL32	.rdata
    1b8b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    1b90:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
    1b95:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    1b9a:	48 8d 44 24 64       	lea    0x64(%rsp),%rax
    1b9f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1ba4:	e8 00 00 00 00       	call   1ba9 <tcp_emu+0x849>
			1ba5: IMAGE_REL_AMD64_REL32	__mingw_sscanf
    1ba9:	89 c5                	mov    %eax,%ebp
    1bab:	83 f8 05             	cmp    $0x5,%eax
    1bae:	0f 8e 12 f9 ff ff    	jle    14c6 <tcp_emu+0x166>
    1bb4:	8b 4c 24 5c          	mov    0x5c(%rsp),%ecx
    1bb8:	8b 44 24 60          	mov    0x60(%rsp),%eax
    1bbc:	c1 e1 18             	shl    $0x18,%ecx
    1bbf:	c1 e0 10             	shl    $0x10,%eax
    1bc2:	09 c1                	or     %eax,%ecx
    1bc4:	8b 44 24 64          	mov    0x64(%rsp),%eax
    1bc8:	0b 4c 24 68          	or     0x68(%rsp),%ecx
    1bcc:	c1 e0 08             	shl    $0x8,%eax
    1bcf:	09 c1                	or     %eax,%ecx
    1bd1:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1bd7 <tcp_emu+0x877>
			1bd3: IMAGE_REL_AMD64_REL32	__imp_htonl
    1bd7:	0f b7 4c 24 6c       	movzwl 0x6c(%rsp),%ecx
    1bdc:	89 44 24 74          	mov    %eax,0x74(%rsp)
    1be0:	c1 e1 08             	shl    $0x8,%ecx
    1be3:	66 0b 4c 24 70       	or     0x70(%rsp),%cx
    1be8:	0f b7 c9             	movzwl %cx,%ecx
    1beb:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1bf1 <tcp_emu+0x891>
			1bed: IMAGE_REL_AMD64_REL32	__imp_htons
    1bf1:	44 8b 4c 24 74       	mov    0x74(%rsp),%r9d
    1bf6:	48 89 f9             	mov    %rdi,%rcx
    1bf9:	45 31 c0             	xor    %r8d,%r8d
    1bfc:	0f b7 c0             	movzwl %ax,%eax
    1bff:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    1c06:	00 
    1c07:	31 d2                	xor    %edx,%edx
    1c09:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1c0d:	89 44 24 78          	mov    %eax,0x78(%rsp)
    1c11:	e8 00 00 00 00       	call   1c16 <tcp_emu+0x8b6>
			1c12: IMAGE_REL_AMD64_REL32	tcp_listen
    1c16:	48 89 c7             	mov    %rax,%rdi
    1c19:	48 85 c0             	test   %rax,%rax
    1c1c:	0f 84 a4 f8 ff ff    	je     14c6 <tcp_emu+0x166>
    1c22:	0f b7 48 52          	movzwl 0x52(%rax),%ecx
    1c26:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1c2c <tcp_emu+0x8cc>
			1c28: IMAGE_REL_AMD64_REL32	__imp_ntohs
    1c2c:	8b 4f 54             	mov    0x54(%rdi),%ecx
    1c2f:	0f b6 d4             	movzbl %ah,%edx
    1c32:	0f b6 c0             	movzbl %al,%eax
    1c35:	89 54 24 6c          	mov    %edx,0x6c(%rsp)
    1c39:	89 44 24 70          	mov    %eax,0x70(%rsp)
    1c3d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1c43 <tcp_emu+0x8e3>
			1c3f: IMAGE_REL_AMD64_REL32	__imp_ntohl
    1c43:	4c 8b 5e 30          	mov    0x30(%rsi),%r11
    1c47:	49 89 da             	mov    %rbx,%r10
    1c4a:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
    1c51:	00 
    1c52:	41 89 c0             	mov    %eax,%r8d
    1c55:	41 89 c1             	mov    %eax,%r9d
    1c58:	0f b6 fc             	movzbl %ah,%edi
    1c5b:	0f b6 c8             	movzbl %al,%ecx
    1c5e:	41 c1 e8 10          	shr    $0x10,%r8d
    1c62:	41 c1 e9 18          	shr    $0x18,%r9d
    1c66:	4d 29 da             	sub    %r11,%r10
    1c69:	89 44 24 74          	mov    %eax,0x74(%rsp)
    1c6d:	83 fd 07             	cmp    $0x7,%ebp
    1c70:	45 0f b6 c0          	movzbl %r8b,%r8d
    1c74:	44 89 4c 24 5c       	mov    %r9d,0x5c(%rsp)
    1c79:	8b 6c 24 6c          	mov    0x6c(%rsp),%ebp
    1c7d:	48 8d 05 71 01 00 00 	lea    0x171(%rip),%rax        # 1df5 <tcp_emu+0xa95>
			1c80: IMAGE_REL_AMD64_REL32	.rdata
    1c84:	44 89 44 24 60       	mov    %r8d,0x60(%rsp)
    1c89:	44 8b 64 24 70       	mov    0x70(%rsp),%r12d
    1c8e:	48 0f 44 c2          	cmove  %rdx,%rax
    1c92:	89 7c 24 64          	mov    %edi,0x64(%rsp)
    1c96:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1c9a:	89 4c 24 68          	mov    %ecx,0x68(%rsp)
    1c9e:	44 89 56 38          	mov    %r10d,0x38(%rsi)
    1ca2:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    1ca6:	0f 84 cb 03 00 00    	je     2077 <tcp_emu+0xd17>
    1cac:	48 03 56 58          	add    0x58(%rsi),%rdx
    1cb0:	4c 29 da             	sub    %r11,%rdx
    1cb3:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
    1cb7:	4d 63 d2             	movslq %r10d,%r10
    1cba:	48 89 d9             	mov    %rbx,%rcx
    1cbd:	44 89 44 24 20       	mov    %r8d,0x20(%rsp)
    1cc2:	4c 29 d2             	sub    %r10,%rdx
    1cc5:	4c 8d 05 18 02 00 00 	lea    0x218(%rip),%r8        # 1ee4 <tcp_emu+0xb84>
			1cc8: IMAGE_REL_AMD64_REL32	.rdata
    1ccc:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    1cd1:	44 89 64 24 40       	mov    %r12d,0x40(%rsp)
    1cd6:	89 6c 24 38          	mov    %ebp,0x38(%rsp)
    1cda:	89 7c 24 28          	mov    %edi,0x28(%rsp)
    1cde:	e8 00 00 00 00       	call   1ce3 <tcp_emu+0x983>
			1cdf: IMAGE_REL_AMD64_REL32	slirp_fmt
    1ce3:	01 46 38             	add    %eax,0x38(%rsi)
    1ce6:	e9 db f7 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1ceb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1cf0:	4d 39 d5             	cmp    %r10,%r13
    1cf3:	73 15                	jae    1d0a <tcp_emu+0x9aa>
    1cf5:	c7 84 24 80 00 00 00 	movl   $0x414e50,0x80(%rsp)
    1cfc:	50 4e 41 00 
    1d00:	31 c0                	xor    %eax,%eax
    1d02:	45 31 c9             	xor    %r9d,%r9d
    1d05:	e9 c1 fc ff ff       	jmp    19cb <tcp_emu+0x66b>
    1d0a:	31 c0                	xor    %eax,%eax
    1d0c:	e9 20 fe ff ff       	jmp    1b31 <tcp_emu+0x7d1>
    1d11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1d18:	49 83 c5 08          	add    $0x8,%r13
    1d1c:	4d 39 d5             	cmp    %r10,%r13
    1d1f:	0f 82 1e fd ff ff    	jb     1a43 <tcp_emu+0x6e3>
    1d25:	b8 06 00 00 00       	mov    $0x6,%eax
    1d2a:	e9 02 fe ff ff       	jmp    1b31 <tcp_emu+0x7d1>
    1d2f:	90                   	nop
    1d30:	0f b7 4c 24 78       	movzwl 0x78(%rsp),%ecx
    1d35:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d3b <tcp_emu+0x9db>
			1d37: IMAGE_REL_AMD64_REL32	__imp_htons
    1d3b:	8b 4c 24 74          	mov    0x74(%rsp),%ecx
    1d3f:	0f b7 e8             	movzwl %ax,%ebp
    1d42:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d48 <tcp_emu+0x9e8>
			1d44: IMAGE_REL_AMD64_REL32	__imp_htonl
    1d48:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
    1d4c:	48 89 f9             	mov    %rdi,%rcx
    1d4f:	45 31 c0             	xor    %r8d,%r8d
    1d52:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    1d59:	00 
    1d5a:	41 89 c1             	mov    %eax,%r9d
    1d5d:	31 d2                	xor    %edx,%edx
    1d5f:	e8 00 00 00 00       	call   1d64 <tcp_emu+0xa04>
			1d60: IMAGE_REL_AMD64_REL32	tcp_listen
    1d64:	48 89 c7             	mov    %rax,%rdi
    1d67:	48 85 c0             	test   %rax,%rax
    1d6a:	0f 84 56 f7 ff ff    	je     14c6 <tcp_emu+0x166>
    1d70:	48 89 d8             	mov    %rbx,%rax
    1d73:	48 2b 46 30          	sub    0x30(%rsi),%rax
    1d77:	89 46 38             	mov    %eax,0x38(%rsi)
    1d7a:	0f b7 4f 52          	movzwl 0x52(%rdi),%ecx
    1d7e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d84 <tcp_emu+0xa24>
			1d80: IMAGE_REL_AMD64_REL32	__imp_ntohs
    1d84:	8b 4f 54             	mov    0x54(%rdi),%ecx
    1d87:	0f b7 e8             	movzwl %ax,%ebp
    1d8a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d90 <tcp_emu+0xa30>
			1d8c: IMAGE_REL_AMD64_REL32	__imp_ntohl
    1d90:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1d94:	41 89 c1             	mov    %eax,%r9d
    1d97:	48 8b 46 30          	mov    0x30(%rsi),%rax
    1d9b:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    1d9f:	0f 84 5c 02 00 00    	je     2001 <tcp_emu+0xca1>
    1da5:	48 03 56 58          	add    0x58(%rsi),%rdx
    1da9:	48 29 c2             	sub    %rax,%rdx
    1dac:	48 63 46 38          	movslq 0x38(%rsi),%rax
    1db0:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    1db7:	00 
    1db8:	4c 8d 05 65 02 00 00 	lea    0x265(%rip),%r8        # 2024 <tcp_emu+0xcc4>
			1dbb: IMAGE_REL_AMD64_REL32	.rdata
    1dbf:	48 89 d9             	mov    %rbx,%rcx
    1dc2:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
    1dc6:	48 29 c2             	sub    %rax,%rdx
    1dc9:	e8 00 00 00 00       	call   1dce <tcp_emu+0xa6e>
			1dca: IMAGE_REL_AMD64_REL32	slirp_fmt
    1dce:	01 46 38             	add    %eax,0x38(%rsi)
    1dd1:	e9 f0 f6 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1ddd:	00 00 00 
    1de0:	0f b7 4c 24 78       	movzwl 0x78(%rsp),%ecx
    1de5:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1deb <tcp_emu+0xa8b>
			1de7: IMAGE_REL_AMD64_REL32	__imp_htons
    1deb:	8b 4c 24 74          	mov    0x74(%rsp),%ecx
    1def:	0f b7 e8             	movzwl %ax,%ebp
    1df2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1df8 <tcp_emu+0xa98>
			1df4: IMAGE_REL_AMD64_REL32	__imp_htonl
    1df8:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
    1dfc:	48 89 f9             	mov    %rdi,%rcx
    1dff:	45 31 c0             	xor    %r8d,%r8d
    1e02:	c7 44 24 28 00 02 00 	movl   $0x200,0x28(%rsp)
    1e09:	00 
    1e0a:	41 89 c1             	mov    %eax,%r9d
    1e0d:	31 d2                	xor    %edx,%edx
    1e0f:	e8 00 00 00 00       	call   1e14 <tcp_emu+0xab4>
			1e10: IMAGE_REL_AMD64_REL32	tcp_listen
    1e14:	48 89 c7             	mov    %rax,%rdi
    1e17:	48 85 c0             	test   %rax,%rax
    1e1a:	0f 84 a6 f6 ff ff    	je     14c6 <tcp_emu+0x166>
    1e20:	48 89 d8             	mov    %rbx,%rax
    1e23:	48 2b 46 30          	sub    0x30(%rsi),%rax
    1e27:	44 8b 64 24 5c       	mov    0x5c(%rsp),%r12d
    1e2c:	89 46 38             	mov    %eax,0x38(%rsi)
    1e2f:	0f b7 4f 52          	movzwl 0x52(%rdi),%ecx
    1e33:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1e39 <tcp_emu+0xad9>
			1e35: IMAGE_REL_AMD64_REL32	__imp_ntohs
    1e39:	8b 4f 54             	mov    0x54(%rdi),%ecx
    1e3c:	0f b7 e8             	movzwl %ax,%ebp
    1e3f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1e45 <tcp_emu+0xae5>
			1e41: IMAGE_REL_AMD64_REL32	__imp_ntohl
    1e45:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1e49:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    1e4d:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    1e51:	0f 84 d7 01 00 00    	je     202e <tcp_emu+0xcce>
    1e57:	48 03 56 58          	add    0x58(%rsi),%rdx
    1e5b:	48 29 ca             	sub    %rcx,%rdx
    1e5e:	48 63 4e 38          	movslq 0x38(%rsi),%rcx
    1e62:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
    1e69:	00 
    1e6a:	4c 8d 8c 24 90 00 00 	lea    0x90(%rsp),%r9
    1e71:	00 
    1e72:	4c 8d 05 95 02 00 00 	lea    0x295(%rip),%r8        # 210e <tcp_ctl+0x2e>
			1e75: IMAGE_REL_AMD64_REL32	.rdata
    1e79:	44 89 64 24 30       	mov    %r12d,0x30(%rsp)
    1e7e:	89 6c 24 28          	mov    %ebp,0x28(%rsp)
    1e82:	48 29 ca             	sub    %rcx,%rdx
    1e85:	48 89 d9             	mov    %rbx,%rcx
    1e88:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1e8c:	e8 00 00 00 00       	call   1e91 <tcp_emu+0xb31>
			1e8d: IMAGE_REL_AMD64_REL32	slirp_fmt
    1e91:	01 46 38             	add    %eax,0x38(%rsi)
    1e94:	e9 2d f6 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1e99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1ea0:	0f b7 4c 24 5c       	movzwl 0x5c(%rsp),%ecx
    1ea5:	48 8b 2d 00 00 00 00 	mov    0x0(%rip),%rbp        # 1eac <tcp_emu+0xb4c>
			1ea8: IMAGE_REL_AMD64_REL32	__imp_htons
    1eac:	48 81 c7 c0 01 00 00 	add    $0x1c0,%rdi
    1eb3:	ff d5                	call   *%rbp
    1eb5:	0f b7 4c 24 60       	movzwl 0x60(%rsp),%ecx
    1eba:	0f b7 c0             	movzwl %ax,%eax
    1ebd:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
    1ec1:	ff d5                	call   *%rbp
    1ec3:	44 8b 4c 24 5c       	mov    0x5c(%rsp),%r9d
    1ec8:	44 0f b7 c0          	movzwl %ax,%r8d
    1ecc:	48 8b 07             	mov    (%rdi),%rax
    1ecf:	44 89 44 24 60       	mov    %r8d,0x60(%rsp)
    1ed4:	48 39 f8             	cmp    %rdi,%rax
    1ed7:	74 77                	je     1f50 <tcp_emu+0xbf0>
    1ed9:	8b 93 d4 00 00 00    	mov    0xd4(%rbx),%edx
    1edf:	eb 17                	jmp    1ef8 <tcp_emu+0xb98>
    1ee1:	0f 1f 40 00          	nopl   0x0(%rax)
    1ee5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    1eec:	00 00 00 00 
    1ef0:	48 8b 00             	mov    (%rax),%rax
    1ef3:	48 39 f8             	cmp    %rdi,%rax
    1ef6:	74 58                	je     1f50 <tcp_emu+0xbf0>
    1ef8:	39 90 d4 00 00 00    	cmp    %edx,0xd4(%rax)
    1efe:	75 f0                	jne    1ef0 <tcp_emu+0xb90>
    1f00:	0f b7 88 d2 00 00 00 	movzwl 0xd2(%rax),%ecx
    1f07:	41 39 c8             	cmp    %ecx,%r8d
    1f0a:	75 e4                	jne    1ef0 <tcp_emu+0xb90>
    1f0c:	8b 4b 54             	mov    0x54(%rbx),%ecx
    1f0f:	39 48 54             	cmp    %ecx,0x54(%rax)
    1f12:	75 dc                	jne    1ef0 <tcp_emu+0xb90>
    1f14:	0f b7 48 52          	movzwl 0x52(%rax),%ecx
    1f18:	44 39 c9             	cmp    %r9d,%ecx
    1f1b:	75 d3                	jne    1ef0 <tcp_emu+0xb90>
    1f1d:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1f21:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
    1f28:	00 
    1f29:	4c 8d 44 24 7c       	lea    0x7c(%rsp),%r8
    1f2e:	e8 00 00 00 00       	call   1f33 <tcp_emu+0xbd3>
			1f2f: IMAGE_REL_AMD64_REL32	slirp_getsockname_wrap
    1f33:	85 c0                	test   %eax,%eax
    1f35:	75 0c                	jne    1f43 <tcp_emu+0xbe3>
    1f37:	0f b7 84 24 82 00 00 	movzwl 0x82(%rsp),%eax
    1f3e:	00 
    1f3f:	89 44 24 60          	mov    %eax,0x60(%rsp)
    1f43:	44 8b 4c 24 5c       	mov    0x5c(%rsp),%r9d
    1f48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1f4f:	00 
    1f50:	41 0f b7 c9          	movzwl %r9w,%ecx
    1f54:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # 1f5b <tcp_emu+0xbfb>
			1f57: IMAGE_REL_AMD64_REL32	__imp_ntohs
    1f5b:	ff d3                	call   *%rbx
    1f5d:	0f b7 4c 24 60       	movzwl 0x60(%rsp),%ecx
    1f62:	0f b7 c0             	movzwl %ax,%eax
    1f65:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
    1f69:	ff d3                	call   *%rbx
    1f6b:	44 8b 4c 24 5c       	mov    0x5c(%rsp),%r9d
    1f70:	4c 8d 05 8b 01 00 00 	lea    0x18b(%rip),%r8        # 2102 <tcp_ctl+0x22>
			1f73: IMAGE_REL_AMD64_REL32	.rdata
    1f77:	31 d2                	xor    %edx,%edx
    1f79:	0f b7 c0             	movzwl %ax,%eax
    1f7c:	31 c9                	xor    %ecx,%ecx
    1f7e:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1f82:	89 44 24 60          	mov    %eax,0x60(%rsp)
    1f86:	e8 00 00 00 00       	call   1f8b <tcp_emu+0xc2b>
			1f87: IMAGE_REL_AMD64_REL32	g_snprintf
    1f8b:	48 89 f1             	mov    %rsi,%rcx
    1f8e:	8d 50 01             	lea    0x1(%rax),%edx
    1f91:	e8 00 00 00 00       	call   1f96 <tcp_emu+0xc36>
			1f92: IMAGE_REL_AMD64_REL32	m_inc
    1f96:	8b 44 24 60          	mov    0x60(%rsp),%eax
    1f9a:	44 8b 4c 24 5c       	mov    0x5c(%rsp),%r9d
    1f9f:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    1fa3:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
    1fa7:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    1fab:	74 61                	je     200e <tcp_emu+0xcae>
    1fad:	48 03 56 58          	add    0x58(%rsi),%rdx
    1fb1:	48 29 ca             	sub    %rcx,%rdx
    1fb4:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1fb8:	4c 8d 05 8b 01 00 00 	lea    0x18b(%rip),%r8        # 214a <tcp_ctl+0x6a>
			1fbb: IMAGE_REL_AMD64_REL32	.rdata
    1fbf:	e8 00 00 00 00       	call   1fc4 <tcp_emu+0xc64>
			1fc0: IMAGE_REL_AMD64_REL32	slirp_fmt
    1fc4:	89 46 38             	mov    %eax,0x38(%rsi)
    1fc7:	e9 fa f4 ff ff       	jmp    14c6 <tcp_emu+0x166>
    1fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    1fd0:	4d 39 d5             	cmp    %r10,%r13
    1fd3:	73 19                	jae    1fee <tcp_emu+0xc8e>
    1fd5:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    1fd9:	4c 8d 6a 02          	lea    0x2(%rdx),%r13
    1fdd:	3c 50                	cmp    $0x50,%al
    1fdf:	0f 85 bf f9 ff ff    	jne    19a4 <tcp_emu+0x644>
    1fe5:	4d 39 d5             	cmp    %r10,%r13
    1fe8:	0f 82 a2 f9 ff ff    	jb     1990 <tcp_emu+0x630>
    1fee:	b8 01 00 00 00       	mov    $0x1,%eax
    1ff3:	40 84 f6             	test   %sil,%sil
    1ff6:	0f 85 35 fb ff ff    	jne    1b31 <tcp_emu+0x7d1>
    1ffc:	e9 c5 f4 ff ff       	jmp    14c6 <tcp_emu+0x166>
    2001:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    2006:	48 29 c2             	sub    %rax,%rdx
    2009:	e9 9e fd ff ff       	jmp    1dac <tcp_emu+0xa4c>
    200e:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    2013:	48 29 ca             	sub    %rcx,%rdx
    2016:	eb 9c                	jmp    1fb4 <tcp_emu+0xc54>
    2018:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    201d:	4c 29 da             	sub    %r11,%rdx
    2020:	e9 6c f6 ff ff       	jmp    1691 <tcp_emu+0x331>
    2025:	31 f6                	xor    %esi,%esi
    2027:	31 c0                	xor    %eax,%eax
    2029:	e9 b9 fa ff ff       	jmp    1ae7 <tcp_emu+0x787>
    202e:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    2033:	48 29 ca             	sub    %rcx,%rdx
    2036:	e9 23 fe ff ff       	jmp    1e5e <tcp_emu+0xafe>
    203b:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    203f:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
    2046:	00 
    2047:	4c 8d 44 24 7c       	lea    0x7c(%rsp),%r8
    204c:	c7 44 24 7c 10 00 00 	movl   $0x10,0x7c(%rsp)
    2053:	00 
    2054:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    205b:	00 
    205c:	e8 00 00 00 00       	call   2061 <tcp_emu+0xd01>
			205d: IMAGE_REL_AMD64_REL32	slirp_getsockname_wrap
    2061:	85 c0                	test   %eax,%eax
    2063:	75 41                	jne    20a6 <tcp_emu+0xd46>
    2065:	8b 8c 24 84 00 00 00 	mov    0x84(%rsp),%ecx
    206c:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2072 <tcp_emu+0xd12>
			206e: IMAGE_REL_AMD64_REL32	__imp_ntohl
    2072:	e9 a9 f5 ff ff       	jmp    1620 <tcp_emu+0x2c0>
    2077:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    207c:	4c 29 da             	sub    %r11,%rdx
    207f:	e9 2f fc ff ff       	jmp    1cb3 <tcp_emu+0x953>
    2084:	40 84 f6             	test   %sil,%sil
    2087:	0f 84 39 f4 ff ff    	je     14c6 <tcp_emu+0x166>
    208d:	c7 05 fc ff ff ff 05 	movl   $0x5,-0x4(%rip)        # 2093 <tcp_emu+0xd33>
    2094:	00 00 00 
			208f: IMAGE_REL_AMD64_REL32	.bss
    2097:	e9 2a f4 ff ff       	jmp    14c6 <tcp_emu+0x166>
    209c:	b8 05 00 00 00       	mov    $0x5,%eax
    20a1:	e9 8b fa ff ff       	jmp    1b31 <tcp_emu+0x7d1>
    20a6:	8b 4f 18             	mov    0x18(%rdi),%ecx
    20a9:	e9 6c f5 ff ff       	jmp    161a <tcp_emu+0x2ba>
    20ae:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    20b3:	48 29 ca             	sub    %rcx,%rdx
    20b6:	e9 e1 f6 ff ff       	jmp    179c <tcp_emu+0x43c>
    20bb:	48 8d 54 16 60       	lea    0x60(%rsi,%rdx,1),%rdx
    20c0:	48 29 ca             	sub    %rcx,%rdx
    20c3:	e9 2e f8 ff ff       	jmp    18f6 <tcp_emu+0x596>
    20c8:	b8 02 00 00 00       	mov    $0x2,%eax
    20cd:	e9 5f fa ff ff       	jmp    1b31 <tcp_emu+0x7d1>
    20d2:	b8 01 00 00 00       	mov    $0x1,%eax
    20d7:	e9 55 fa ff ff       	jmp    1b31 <tcp_emu+0x7d1>
    20dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000020e0 <tcp_ctl>:
    20e0:	56                   	push   %rsi
    20e1:	53                   	push   %rbx
    20e2:	48 83 ec 28          	sub    $0x28,%rsp
    20e6:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 20ed <tcp_ctl+0xd>
			20e9: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    20ed:	48 8b 71 30          	mov    0x30(%rcx),%rsi
    20f1:	48 89 cb             	mov    %rcx,%rbx
    20f4:	f6 00 01             	testb  $0x1,(%rax)
    20f7:	0f 85 b3 00 00 00    	jne    21b0 <tcp_ctl+0xd0>
    20fd:	8b 4b 54             	mov    0x54(%rbx),%ecx
    2100:	3b 4e 18             	cmp    0x18(%rsi),%ecx
    2103:	74 5b                	je     2160 <tcp_ctl+0x80>
    2105:	48 8b b6 88 00 00 00 	mov    0x88(%rsi),%rsi
    210c:	48 85 f6             	test   %rsi,%rsi
    210f:	74 4f                	je     2160 <tcp_ctl+0x80>
    2111:	0f b7 53 52          	movzwl 0x52(%rbx),%edx
    2115:	eb 12                	jmp    2129 <tcp_ctl+0x49>
    2117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    211e:	00 00 
    2120:	48 8b 76 28          	mov    0x28(%rsi),%rsi
    2124:	48 85 f6             	test   %rsi,%rsi
    2127:	74 37                	je     2160 <tcp_ctl+0x80>
    2129:	39 56 14             	cmp    %edx,0x14(%rsi)
    212c:	75 f2                	jne    2120 <tcp_ctl+0x40>
    212e:	3b 4e 10             	cmp    0x10(%rsi),%ecx
    2131:	75 ed                	jne    2120 <tcp_ctl+0x40>
    2133:	48 83 3e 00          	cmpq   $0x0,(%rsi)
    2137:	0f 84 bb 00 00 00    	je     21f8 <tcp_ctl+0x118>
    213d:	b8 01 00 00 00       	mov    $0x1,%eax
    2142:	48 c7 43 10 ff ff ff 	movq   $0xffffffffffffffff,0x10(%rbx)
    2149:	ff 
    214a:	48 89 73 20          	mov    %rsi,0x20(%rbx)
    214e:	48 83 c4 28          	add    $0x28,%rsp
    2152:	5b                   	pop    %rbx
    2153:	5e                   	pop    %rsi
    2154:	31 d2                	xor    %edx,%edx
    2156:	31 c9                	xor    %ecx,%ecx
    2158:	45 31 c0             	xor    %r8d,%r8d
    215b:	45 31 c9             	xor    %r9d,%r9d
    215e:	c3                   	ret
    215f:	90                   	nop
    2160:	48 8b 8b 98 01 00 00 	mov    0x198(%rbx),%rcx
    2167:	8b 93 94 01 00 00    	mov    0x194(%rbx),%edx
    216d:	4c 8d 05 38 03 00 00 	lea    0x338(%rip),%r8        # 24ac <tcp_ctl+0x3cc>
			2170: IMAGE_REL_AMD64_REL32	.rdata
    2174:	48 89 c8             	mov    %rcx,%rax
    2177:	48 2b 83 a8 01 00 00 	sub    0x1a8(%rbx),%rax
    217e:	48 29 c2             	sub    %rax,%rdx
    2181:	e8 00 00 00 00       	call   2186 <tcp_ctl+0xa6>
			2182: IMAGE_REL_AMD64_REL32	slirp_fmt
    2186:	89 83 90 01 00 00    	mov    %eax,0x190(%rbx)
    218c:	89 c0                	mov    %eax,%eax
    218e:	48 01 83 98 01 00 00 	add    %rax,0x198(%rbx)
    2195:	31 c0                	xor    %eax,%eax
    2197:	48 83 c4 28          	add    $0x28,%rsp
    219b:	5b                   	pop    %rbx
    219c:	5e                   	pop    %rsi
    219d:	31 d2                	xor    %edx,%edx
    219f:	31 c9                	xor    %ecx,%ecx
    21a1:	45 31 c0             	xor    %r8d,%r8d
    21a4:	45 31 c9             	xor    %r9d,%r9d
    21a7:	c3                   	ret
    21a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    21af:	00 
    21b0:	4c 8d 05 1c 03 00 00 	lea    0x31c(%rip),%r8        # 24d3 <tcp_ctl+0x3f3>
			21b3: IMAGE_REL_AMD64_REL32	.rdata
    21b7:	ba 80 00 00 00       	mov    $0x80,%edx
    21bc:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 21ed <tcp_ctl+0x10d>
			21bf: IMAGE_REL_AMD64_REL32	.rdata
    21c3:	e8 00 00 00 00       	call   21c8 <tcp_ctl+0xe8>
			21c4: IMAGE_REL_AMD64_REL32	g_log
    21c8:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 21cf <tcp_ctl+0xef>
			21cb: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    21cf:	f6 00 01             	testb  $0x1,(%rax)
    21d2:	0f 84 25 ff ff ff    	je     20fd <tcp_ctl+0x1d>
    21d8:	49 89 d9             	mov    %rbx,%r9
    21db:	4c 8d 05 c0 00 00 00 	lea    0xc0(%rip),%r8        # 22a2 <tcp_ctl+0x1c2>
			21de: IMAGE_REL_AMD64_REL32	.rdata
    21e2:	ba 80 00 00 00       	mov    $0x80,%edx
    21e7:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 2218 <tcp_ctl+0x138>
			21ea: IMAGE_REL_AMD64_REL32	.rdata
    21ee:	e8 00 00 00 00       	call   21f3 <tcp_ctl+0x113>
			21ef: IMAGE_REL_AMD64_REL32	g_log
    21f3:	e9 05 ff ff ff       	jmp    20fd <tcp_ctl+0x1d>
    21f8:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 21ff <tcp_ctl+0x11f>
			21fb: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    21ff:	f6 00 02             	testb  $0x2,(%rax)
    2202:	75 17                	jne    221b <tcp_ctl+0x13b>
    2204:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    2208:	48 85 d2             	test   %rdx,%rdx
    220b:	74 2c                	je     2239 <tcp_ctl+0x159>
    220d:	48 89 d9             	mov    %rbx,%rcx
    2210:	48 83 c4 28          	add    $0x28,%rsp
    2214:	5b                   	pop    %rbx
    2215:	5e                   	pop    %rsi
    2216:	e9 00 00 00 00       	jmp    221b <tcp_ctl+0x13b>
			2217: IMAGE_REL_AMD64_REL32	open_unix
    221b:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
    221f:	4c 8d 05 27 03 00 00 	lea    0x327(%rip),%r8        # 254d <tcp_ctl+0x46d>
			2222: IMAGE_REL_AMD64_REL32	.rdata
    2226:	ba 80 00 00 00       	mov    $0x80,%edx
    222b:	48 8d 0d 2a 00 00 00 	lea    0x2a(%rip),%rcx        # 225c <tcp_ctl+0x17c>
			222e: IMAGE_REL_AMD64_REL32	.rdata
    2232:	e8 00 00 00 00       	call   2237 <tcp_ctl+0x157>
			2233: IMAGE_REL_AMD64_REL32	g_log
    2237:	eb cb                	jmp    2204 <tcp_ctl+0x124>
    2239:	48 8b 56 18          	mov    0x18(%rsi),%rdx
    223d:	48 89 d9             	mov    %rbx,%rcx
    2240:	48 83 c4 28          	add    $0x28,%rsp
    2244:	5b                   	pop    %rbx
    2245:	5e                   	pop    %rsi
    2246:	e9 00 00 00 00       	jmp    224b <tcp_ctl+0x16b>
			2247: IMAGE_REL_AMD64_REL32	fork_exec
    224b:	90                   	nop
    224c:	90                   	nop
    224d:	90                   	nop
    224e:	90                   	nop
    224f:	90                   	nop
    2250:	90                   	nop
    2251:	90                   	nop
    2252:	90                   	nop
    2253:	90                   	nop
    2254:	90                   	nop
    2255:	90                   	nop
    2256:	90                   	nop
    2257:	90                   	nop
    2258:	90                   	nop
    2259:	90                   	nop
    225a:	90                   	nop
    225b:	90                   	nop
    225c:	90                   	nop
    225d:	90                   	nop
    225e:	90                   	nop
    225f:	90                   	nop
    2260:	90                   	nop
    2261:	90                   	nop
    2262:	90                   	nop
    2263:	90                   	nop
    2264:	90                   	nop
    2265:	90                   	nop
    2266:	90                   	nop
    2267:	90                   	nop
    2268:	90                   	nop
    2269:	90                   	nop
    226a:	90                   	nop
    226b:	90                   	nop
    226c:	90                   	nop
    226d:	90                   	nop
    226e:	90                   	nop
    226f:	90                   	nop
    2270:	90                   	nop
    2271:	90                   	nop
    2272:	90                   	nop
    2273:	90                   	nop
    2274:	90                   	nop
    2275:	90                   	nop
    2276:	90                   	nop
    2277:	90                   	nop
    2278:	90                   	nop
    2279:	90                   	nop
    227a:	90                   	nop
    227b:	90                   	nop
    227c:	90                   	nop
    227d:	90                   	nop
    227e:	90                   	nop
    227f:	90                   	nop
