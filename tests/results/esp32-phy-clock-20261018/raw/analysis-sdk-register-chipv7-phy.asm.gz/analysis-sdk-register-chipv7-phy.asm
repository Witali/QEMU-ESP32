In archive C:\Users\rudol\AppData\Local\Arduino15\packages\esp32\tools\esp32-libs\3.3.8\ld\libphy.a:

phy_chip_v7.o:     file format elf32-xtensa-le


Disassembly of section .text.register_chipv7_phy:

00000000 <register_chipv7_phy-0xa8>:
   0:	00200008 	
   4:	60033c00 	
	...
			8: R_XTENSA_32	re_entry
			c: R_XTENSA_32	phy_init_flag
			10: R_XTENSA_32	force_hw_set_freq_flag
  14:	3ff4e0c4 	
	...
			18: R_XTENSA_32	chip7_sleep_params
			1c: R_XTENSA_32	chip7_phy_init_ctrl
			20: R_XTENSA_32	pwrdet_offset
			24: R_XTENSA_32	phy_in_most_power
  28:	fffeddd7 	
	...
			2c: R_XTENSA_32	g_phyFuns
			30: R_XTENSA_32	btpwr_tsen_init
			34: R_XTENSA_32	btpwr_tsen_old
			38: R_XTENSA_32	init_wifi_disable
  3c:	3ff5c080 	
	...
			40: R_XTENSA_32	phy_wakeup_init
			44: R_XTENSA_32	phy_get_romfunc_addr
			48: R_XTENSA_32	reset_rf_dig
			4c: R_XTENSA_32	phy_dis_hw_set_freq
			50: R_XTENSA_32	esp_dport_access_reg_read
			54: R_XTENSA_32	i2c_master_reset
			58: R_XTENSA_32	phy_rfcal_data_check
			5c: R_XTENSA_32	phy_rfcal_data_check_value
			60: R_XTENSA_32	register_chipv7_phy_init_param
			64: R_XTENSA_32	rf_cal_data_recovery
			68: R_XTENSA_32	write_freq_mem_all
			6c: R_XTENSA_32	rf_init
			70: R_XTENSA_32	bb_init
			74: R_XTENSA_32	phy_rfcal_data_check_value
			78: R_XTENSA_32	rf_cal_data_backup
			7c: R_XTENSA_32	phy_rfcal_data_check
			80: R_XTENSA_32	chip_v7_set_chan_nomac
			84: R_XTENSA_32	force_txrxoff
			88: R_XTENSA_32	chip_v7_set_chan_nomac
			8c: R_XTENSA_32	chip_v7_set_chan_offset
			90: R_XTENSA_32	tsens_code_read
			94: R_XTENSA_32	phy_en_hw_set_freq
			98: R_XTENSA_32	enable_wifi_agc
			9c: R_XTENSA_32	esp_dport_access_reg_read
			a0: R_XTENSA_32	rf_init
			a4: R_XTENSA_32	bb_init

000000a8 <register_chipv7_phy>:
  a8:	020136        	entry	a1, 0x100
  ab:	ffd651        	l32r	a5, 4 <register_chipv7_phy-0xa4> (60033c00 <phy_close_rf+0x600332b8>)
			ab: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x4
  ae:	744040        	extui	a4, a4, 0, 8
  b1:	0020c0        	memw
  b4:	0558      	l32i.n	a5, a5, 0
  b6:	728c      	beqz.n	a2, c1 <register_chipv7_phy+0x19>
			b6: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xc1
  b8:	ffd451        	l32r	a5, 8 <register_chipv7_phy-0xa0> (0 <register_chipv7_phy-0xa8>)
			b8: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x8
  bb:	000562        	l8ui	a6, a5, 0
  be:	0a1666        	bnei	a6, 1, cc <register_chipv7_phy+0x24>
			be: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xcc
  c1:	ffdf81        	l32r	a8, 40 <register_chipv7_phy-0x68> (0 <register_chipv7_phy-0xa8>)
			c1: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x40
			c1: R_XTENSA_ASM_EXPAND	phy_wakeup_init
  c4:	0008e0        	callx8	a8
  c7:	020c      	movi.n	a2, 0
  c9:	f01d      	retw.n
  cb:	00          	.byte	00
  cc:	ffd081        	l32r	a8, c <register_chipv7_phy-0x9c> (0 <register_chipv7_phy-0xa8>)
			cc: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xc
  cf:	170c      	movi.n	a7, 1
  d1:	ffcf91        	l32r	a9, 10 <register_chipv7_phy-0x98> (0 <register_chipv7_phy-0xa8>)
			d1: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x10
  d4:	004872        	s8i	a7, a8, 0
  d7:	004972        	s8i	a7, a9, 0
  da:	0020c0        	memw
  dd:	a6cc      	bnez.n	a6, eb <register_chipv7_phy+0x43>
			dd: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xeb
  df:	ffd981        	l32r	a8, 44 <register_chipv7_phy-0x64> (0 <register_chipv7_phy-0xa8>)
			df: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x44
			df: R_XTENSA_ASM_EXPAND	phy_get_romfunc_addr
  e2:	0008e0        	callx8	a8
  e5:	ffd881        	l32r	a8, 48 <register_chipv7_phy-0x60> (0 <register_chipv7_phy-0xa8>)
			e5: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x48
			e5: R_XTENSA_ASM_EXPAND	reset_rf_dig
  e8:	0008e0        	callx8	a8
  eb:	ffd881        	l32r	a8, 4c <register_chipv7_phy-0x5c> (0 <register_chipv7_phy-0xa8>)
			eb: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x4c
			eb: R_XTENSA_ASM_EXPAND	phy_dis_hw_set_freq
  ee:	0008e0        	callx8	a8
  f1:	ffc861        	l32r	a6, 14 <register_chipv7_phy-0x94> (3ff4e0c4 <phy_close_rf+0x3ff4d77c>)
			f1: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x14
  f4:	ffae72        	movi	a7, 0xfffffeff
  f7:	20a660        	or	a10, a6, a6
  fa:	ffd581        	l32r	a8, 50 <register_chipv7_phy-0x58> (0 <register_chipv7_phy-0xa8>)
			fa: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x50
			fa: R_XTENSA_ASM_EXPAND	esp_dport_access_reg_read
  fd:	0008e0        	callx8	a8
 100:	10aa70        	and	a10, a10, a7
 103:	0020c0        	memw
 106:	06a9      	s32i.n	a10, a6, 0
 108:	ffd381        	l32r	a8, 54 <register_chipv7_phy-0x54> (0 <register_chipv7_phy-0xa8>)
			108: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x54
			108: R_XTENSA_ASM_EXPAND	i2c_master_reset
 10b:	0008e0        	callx8	a8
 10e:	000572        	l8ui	a7, a5, 0
 111:	21c756        	bnez	a7, 331 <register_chipv7_phy+0x289>
			111: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x331
 114:	02cd      	mov.n	a12, a2
 116:	03bd      	mov.n	a11, a3
 118:	1a0c      	movi.n	a10, 1
 11a:	ffcf81        	l32r	a8, 58 <register_chipv7_phy-0x50> (0 <register_chipv7_phy-0xa8>)
			11a: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x58
			11a: R_XTENSA_ASM_EXPAND	phy_rfcal_data_check
 11d:	0008e0        	callx8	a8
 120:	0a6d      	mov.n	a6, a10
 122:	190c      	movi.n	a9, 1
 124:	0124b6        	bltui	a4, 2, 129 <register_chipv7_phy+0x81>
			124: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x129
 127:	079d      	mov.n	a9, a7
 129:	080c      	movi.n	a8, 0
 12b:	747090        	extui	a7, a9, 0, 8
 12e:	1a0c      	movi.n	a10, 1
 130:	089d      	mov.n	a9, a8
 132:	939a60        	movnez	a9, a10, a6
 135:	109790        	and	a9, a7, a9
 138:	346192        	s32i	a9, a1, 208
 13b:	021987        	beq	a9, a8, 141 <register_chipv7_phy+0x99>
			13b: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x141
 13e:	007386        	j	310 <register_chipv7_phy+0x268>
			13e: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x310
 141:	840b      	addi.n	a8, a4, -1
 143:	939a80        	movnez	a9, a10, a8
 146:	346192        	s32i	a9, a1, 208
 149:	0071c6        	j	314 <register_chipv7_phy+0x26c>
			149: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x314
 14c:	00          	.byte	00
 14d:	08cd      	mov.n	a12, a8
 14f:	01bd      	mov.n	a11, a1
 151:	03ad      	mov.n	a10, a3
 153:	356182        	s32i	a8, a1, 212
 156:	ffc181        	l32r	a8, 5c <register_chipv7_phy-0x4c> (0 <register_chipv7_phy-0xa8>)
			156: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x5c
			156: R_XTENSA_ASM_EXPAND	phy_rfcal_data_check_value
 159:	0008e0        	callx8	a8
 15c:	ffaf91        	l32r	a9, 18 <register_chipv7_phy-0x90> (0 <register_chipv7_phy-0xa8>)
			15c: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x18
 15f:	352182        	l32i	a8, a1, 212
 162:	0989      	s32i.n	a8, a9, 0
 164:	02ad      	mov.n	a10, a2
 166:	ffbe81        	l32r	a8, 60 <register_chipv7_phy-0x48> (0 <register_chipv7_phy-0xa8>)
			166: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x60
			166: R_XTENSA_ASM_EXPAND	register_chipv7_phy_init_param
 169:	0008e0        	callx8	a8
 16c:	ffaca1        	l32r	a10, 1c <register_chipv7_phy-0x8c> (0 <register_chipv7_phy-0xa8>)
			16c: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1c
 16f:	330a82        	l8ui	a8, a10, 51
 172:	0e1866        	bnei	a8, 1, 184 <register_chipv7_phy+0xdc>
			172: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x184
 175:	38a192        	movi	a9, 0x138
 178:	ffaa81        	l32r	a8, 20 <register_chipv7_phy-0x88> (0 <register_chipv7_phy-0xa8>)
			178: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x20
 17b:	005892        	s16i	a9, a8, 0
 17e:	0020c0        	memw
 181:	0002c6        	j	190 <register_chipv7_phy+0xe8>
			181: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x190
 184:	ffa781        	l32r	a8, 20 <register_chipv7_phy-0x88> (0 <register_chipv7_phy-0xa8>)
			184: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x20
 187:	20a192        	movi	a9, 0x120
 18a:	005892        	s16i	a9, a8, 0
 18d:	0020c0        	memw
 190:	0b0c      	movi.n	a11, 0
 192:	180c      	movi.n	a8, 1
 194:	f03d      	nop.n
 196:	f03d      	nop.n
 198:	000592        	l8ui	a9, a5, 0
 19b:	938b90        	movnez	a8, a11, a9
 19e:	108780        	and	a8, a7, a8
 1a1:	0e0ab2        	l8ui	a11, a10, 14
 1a4:	ffa0a1        	l32r	a10, 24 <register_chipv7_phy-0x84> (0 <register_chipv7_phy-0xa8>)
			1a4: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x24
 1a7:	004ab2        	s8i	a11, a10, 0
 1aa:	0020c0        	memw
 1ad:	013816        	beqz	a8, 1c4 <register_chipv7_phy+0x11c>
			1ad: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1c4
 1b0:	20a330        	or	a10, a3, a3
 1b3:	356182        	s32i	a8, a1, 212
 1b6:	ffab81        	l32r	a8, 64 <register_chipv7_phy-0x44> (0 <register_chipv7_phy-0xa8>)
			1b6: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x64
			1b6: R_XTENSA_ASM_EXPAND	rf_cal_data_recovery
 1b9:	0008e0        	callx8	a8
 1bc:	352182        	l32i	a8, a1, 212
 1bf:	087d      	mov.n	a7, a8
 1c1:	000592        	l8ui	a9, a5, 0
 1c4:	69ec      	bnez.n	a9, 1ee <register_chipv7_phy+0x146>
			1c4: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1ee
 1c6:	ff9491        	l32r	a9, 18 <register_chipv7_phy-0x90> (0 <register_chipv7_phy-0xa8>)
			1c6: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x18
 1c9:	ff9781        	l32r	a8, 28 <register_chipv7_phy-0x80> (fffeddd7 <phy_close_rf+0xfffed48f>)
			1c9: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x28
 1cc:	09a8      	l32i.n	a10, a9, 0
 1ce:	108a80        	and	a8, a10, a8
 1d1:	0989      	s32i.n	a8, a9, 0
 1d3:	17e416        	beqz	a4, 355 <register_chipv7_phy+0x2ad>
			1d3: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x355
 1d6:	8b0c      	movi.n	a11, 8
 1d8:	0524f6        	bgeui	a4, 2, 1e1 <register_chipv7_phy+0x139>
			1d8: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1e1
 1db:	005246        	j	328 <register_chipv7_phy+0x280>
			1db: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x328
 1de:	20b8b0        	or	a11, a8, a11
 1e1:	09b9      	s32i.n	a11, a9, 0
 1e3:	0001c6        	j	1ee <register_chipv7_phy+0x146>
			1e3: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1ee
 1e6:	a3cb      	addi.n	a10, a3, 12
 1e8:	ffa081        	l32r	a8, 68 <register_chipv7_phy-0x40> (0 <register_chipv7_phy-0xa8>)
			1e8: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x68
			1e8: R_XTENSA_ASM_EXPAND	write_freq_mem_all
 1eb:	0008e0        	callx8	a8
 1ee:	ff9f81        	l32r	a8, 6c <register_chipv7_phy-0x3c> (0 <register_chipv7_phy-0xa8>)
			1ee: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x6c
			1ee: R_XTENSA_ASM_EXPAND	rf_init
 1f1:	0008e0        	callx8	a8
 1f4:	ff9f81        	l32r	a8, 70 <register_chipv7_phy-0x38> (0 <register_chipv7_phy-0xa8>)
			1f4: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x70
			1f4: R_XTENSA_ASM_EXPAND	bb_init
 1f7:	0008e0        	callx8	a8
 1fa:	000582        	l8ui	a8, a5, 0
 1fd:	38fc      	bnez.n	a8, 234 <register_chipv7_phy+0x18c>
			1fd: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x234
 1ff:	342142        	l32i	a4, a1, 208
 202:	e4ac      	beqz.n	a4, 234 <register_chipv7_phy+0x18c>
			202: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x234
 204:	56dc      	bnez.n	a6, 21d <register_chipv7_phy+0x175>
			204: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x21d
 206:	1c0c      	movi.n	a12, 1
 208:	01bd      	mov.n	a11, a1
 20a:	03ad      	mov.n	a10, a3
 20c:	ff9a81        	l32r	a8, 74 <register_chipv7_phy-0x34> (0 <register_chipv7_phy-0xa8>)
			20c: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x74
			20c: R_XTENSA_ASM_EXPAND	phy_rfcal_data_check_value
 20f:	0008e0        	callx8	a8
 212:	040c      	movi.n	a4, 0
 214:	01a062        	movi	a6, 1
 217:	8364a0        	moveqz	a6, a4, a10
 21a:	746060        	extui	a6, a6, 0, 8
 21d:	03ad      	mov.n	a10, a3
 21f:	ff9681        	l32r	a8, 78 <register_chipv7_phy-0x30> (0 <register_chipv7_phy-0xa8>)
			21f: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x78
			21f: R_XTENSA_ASM_EXPAND	rf_cal_data_backup
 222:	0008e0        	callx8	a8
 225:	02cd      	mov.n	a12, a2
 227:	03bd      	mov.n	a11, a3
 229:	0a0c      	movi.n	a10, 0
 22b:	ff9481        	l32r	a8, 7c <register_chipv7_phy-0x2c> (0 <register_chipv7_phy-0xa8>)
			22b: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x7c
			22b: R_XTENSA_ASM_EXPAND	phy_rfcal_data_check
 22e:	0008e0        	callx8	a8
 231:	000582        	l8ui	a8, a5, 0
 234:	321866        	bnei	a8, 1, 26a <register_chipv7_phy+0x1c2>
			234: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x26a
 237:	63a0d2        	movi	a13, 99
 23a:	0c0c      	movi.n	a12, 0
 23c:	4b0c      	movi.n	a11, 4
 23e:	ff7b21        	l32r	a2, 2c <register_chipv7_phy-0x7c> (0 <register_chipv7_phy-0xa8>)
			23e: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x2c
 241:	65a0a2        	movi	a10, 101
 244:	0238      	l32i.n	a3, a2, 0
 246:	282332        	l32i	a3, a3, 160
 249:	0003e0        	callx8	a3
 24c:	ab0c      	movi.n	a11, 10
 24e:	ff7231        	l32r	a3, 18 <register_chipv7_phy-0x90> (0 <register_chipv7_phy-0xa8>)
			24e: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x18
 251:	5103a2        	l8ui	a10, a3, 81
 254:	23aa00        	sext	a10, a10, 7
 257:	ff8a81        	l32r	a8, 80 <register_chipv7_phy-0x28> (0 <register_chipv7_phy-0xa8>)
			257: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x80
			257: R_XTENSA_ASM_EXPAND	chip_v7_set_chan_nomac
 25a:	0008e0        	callx8	a8
 25d:	0a0c      	movi.n	a10, 0
 25f:	ff8981        	l32r	a8, 84 <register_chipv7_phy-0x24> (0 <register_chipv7_phy-0xa8>)
			25f: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x84
			25f: R_XTENSA_ASM_EXPAND	force_txrxoff
 262:	0008e0        	callx8	a8
 265:	000a46        	j	292 <register_chipv7_phy+0x1ea>
			265: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x292
 268:	00          	.byte	00
 269:	00          	.byte	00
 26a:	f78c      	beqz.n	a7, 27d <register_chipv7_phy+0x1d5>
			26a: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x27d
 26c:	ff6b21        	l32r	a2, 18 <register_chipv7_phy-0x90> (0 <register_chipv7_phy-0xa8>)
			26c: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x18
 26f:	ab0c      	movi.n	a11, 10
 271:	5102a2        	l8ui	a10, a2, 81
 274:	23aa00        	sext	a10, a10, 7
 277:	ff8481        	l32r	a8, 88 <register_chipv7_phy-0x20> (0 <register_chipv7_phy-0xa8>)
			277: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x88
			277: R_XTENSA_ASM_EXPAND	chip_v7_set_chan_nomac
 27a:	0008e0        	callx8	a8
 27d:	ff6721        	l32r	a2, 1c <register_chipv7_phy-0x8c> (0 <register_chipv7_phy-0xa8>)
			27d: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1c
 280:	4e0232        	l8ui	a3, a2, 78
 283:	ff6a21        	l32r	a2, 2c <register_chipv7_phy-0x7c> (0 <register_chipv7_phy-0xa8>)
			283: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x2c
 286:	008316        	beqz	a3, 292 <register_chipv7_phy+0x1ea>
			286: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x292
 289:	00a0a2        	movi	a10, 0
 28c:	ff8081        	l32r	a8, 8c <register_chipv7_phy-0x1c> (0 <register_chipv7_phy-0xa8>)
			28c: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x8c
			28c: R_XTENSA_ASM_EXPAND	chip_v7_set_chan_offset
 28f:	0008e0        	callx8	a8
 292:	0c0c      	movi.n	a12, 0
 294:	0228      	l32i.n	a2, a2, 0
 296:	0cbd      	mov.n	a11, a12
 298:	63a0a2        	movi	a10, 99
 29b:	262222        	l32i	a2, a2, 152
 29e:	0002e0        	callx8	a2
 2a1:	000522        	l8ui	a2, a5, 0
 2a4:	e2dc      	bnez.n	a2, 2c6 <register_chipv7_phy+0x21e>
			2a4: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x2c6
 2a6:	ff7a81        	l32r	a8, 90 <register_chipv7_phy-0x18> (0 <register_chipv7_phy-0xa8>)
			2a6: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x90
			2a6: R_XTENSA_ASM_EXPAND	tsens_code_read
 2a9:	0008e0        	callx8	a8
 2ac:	ff6121        	l32r	a2, 30 <register_chipv7_phy-0x78> (0 <register_chipv7_phy-0xa8>)
			2ac: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x30
 2af:	0042a2        	s8i	a10, a2, 0
 2b2:	0020c0        	memw
 2b5:	f03d      	nop.n
 2b7:	f03d      	nop.n
 2b9:	f03d      	nop.n
 2bb:	f03d      	nop.n
 2bd:	ff5d21        	l32r	a2, 34 <register_chipv7_phy-0x74> (0 <register_chipv7_phy-0xa8>)
			2bd: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x34
 2c0:	0042a2        	s8i	a10, a2, 0
 2c3:	0020c0        	memw
 2c6:	020c      	movi.n	a2, 0
 2c8:	130c      	movi.n	a3, 1
 2ca:	0020f0        	nop
 2cd:	0020f0        	nop
 2d0:	ff4f81        	l32r	a8, c <register_chipv7_phy-0x9c> (0 <register_chipv7_phy-0xa8>)
			2d0: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xc
 2d3:	ff4f91        	l32r	a9, 10 <register_chipv7_phy-0x98> (0 <register_chipv7_phy-0xa8>)
			2d3: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x10
 2d6:	004822        	s8i	a2, a8, 0
 2d9:	004922        	s8i	a2, a9, 0
 2dc:	004532        	s8i	a3, a5, 0
 2df:	0020c0        	memw
 2e2:	ff6c81        	l32r	a8, 94 <register_chipv7_phy-0x14> (0 <register_chipv7_phy-0xa8>)
			2e2: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x94
			2e2: R_XTENSA_ASM_EXPAND	phy_en_hw_set_freq
 2e5:	0008e0        	callx8	a8
 2e8:	ff6c81        	l32r	a8, 98 <register_chipv7_phy-0x10> (0 <register_chipv7_phy-0xa8>)
			2e8: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x98
			2e8: R_XTENSA_ASM_EXPAND	enable_wifi_agc
 2eb:	0008e0        	callx8	a8
 2ee:	ff5221        	l32r	a2, 38 <register_chipv7_phy-0x70> (0 <register_chipv7_phy-0xa8>)
			2ee: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x38
 2f1:	000222        	l8ui	a2, a2, 0
 2f4:	429c      	beqz.n	a2, 30c <register_chipv7_phy+0x264>
			2f4: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x30c
 2f6:	c0a022        	movi	a2, 192
 2f9:	ff5031        	l32r	a3, 3c <register_chipv7_phy-0x6c> (3ff5c080 <phy_close_rf+0x3ff5b738>)
			2f9: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x3c
 2fc:	03ad      	mov.n	a10, a3
 2fe:	ff6781        	l32r	a8, 9c <register_chipv7_phy-0xc> (0 <register_chipv7_phy-0xa8>)
			2fe: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x9c
			2fe: R_XTENSA_ASM_EXPAND	esp_dport_access_reg_read
 301:	0008e0        	callx8	a8
 304:	20aa20        	or	a10, a10, a2
 307:	0020c0        	memw
 30a:	03a9      	s32i.n	a10, a3, 0
 30c:	062d      	mov.n	a2, a6
 30e:	f01d      	retw.n
 310:	087d      	mov.n	a7, a8
 312:	240c      	movi.n	a4, 2
 314:	080c      	movi.n	a8, 0
 316:	021687        	beq	a6, a8, 31c <register_chipv7_phy+0x274>
			316: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x31c
 319:	ff91c6        	j	164 <register_chipv7_phy+0xbc>
			319: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x164
 31c:	342192        	l32i	a9, a1, 208
 31f:	029987        	bne	a9, a8, 325 <register_chipv7_phy+0x27d>
			31f: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x325
 322:	ff8f86        	j	164 <register_chipv7_phy+0xbc>
			322: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x164
 325:	ff8906        	j	14d <register_chipv7_phy+0xa5>
			325: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x14d
 328:	026a47        	bbci	a10, 4, 32e <register_chipv7_phy+0x286>
			328: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x32e
 32b:	ffadc6        	j	1e6 <register_chipv7_phy+0x13e>
			32b: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1e6
 32e:	ffab06        	j	1de <register_chipv7_phy+0x136>
			32e: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1de
 331:	170c      	movi.n	a7, 1
 333:	0124b6        	bltui	a4, 2, 338 <register_chipv7_phy+0x290>
			333: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x338
 336:	070c      	movi.n	a7, 0
 338:	ff5a81        	l32r	a8, a0 <register_chipv7_phy-0x8> (0 <register_chipv7_phy-0xa8>)
			338: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xa0
			338: R_XTENSA_ASM_EXPAND	rf_init
 33b:	0008e0        	callx8	a8
 33e:	ff5981        	l32r	a8, a4 <register_chipv7_phy-0x4> (0 <register_chipv7_phy-0xa8>)
			33e: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0xa4
			33e: R_XTENSA_ASM_EXPAND	bb_init
 341:	0008e0        	callx8	a8
 344:	747070        	extui	a7, a7, 0, 8
 347:	000582        	l8ui	a8, a5, 0
 34a:	021426        	beqi	a4, 1, 350 <register_chipv7_phy+0x2a8>
			34a: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x350
 34d:	eb5816        	beqz	a8, 206 <register_chipv7_phy+0x15e>
			34d: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x206
 350:	060c      	movi.n	a6, 0
 352:	ffb786        	j	234 <register_chipv7_phy+0x18c>
			352: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x234
 355:	ff2ab1        	l32r	a11, 0 <register_chipv7_phy-0xa8> (200008 <phy_close_rf+0x1ff6c0>)
			355: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy
 358:	ffa146        	j	1e1 <register_chipv7_phy+0x139>
			358: R_XTENSA_SLOT0_OP	.text.register_chipv7_phy+0x1e1

phy.o:     file format elf32-xtensa-le


phy_fpga_v7_cal.o:     file format elf32-xtensa-le


phy_chip_v7_cal.o:     file format elf32-xtensa-le


phy_fpga_v7_init.o:     file format elf32-xtensa-le


phy_chip_v7_ana.o:     file format elf32-xtensa-le

