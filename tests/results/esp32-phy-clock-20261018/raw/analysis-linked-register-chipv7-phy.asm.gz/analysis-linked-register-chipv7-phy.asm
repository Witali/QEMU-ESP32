
C:\Work\yoRadio\.build\cyd-phy-analysis-20261018\app-irom.bin:     file format binary


Disassembly of section .data:

401b9914 <.data+0xe98f4>:
401b9914:	360102        	entry	a1, 0x100
401b9917:	5120f6        	l32r	a5, 0x401b7198 (0x60033c00)
401b991a:	404074        	extui	a4, a4, 0, 8
401b991d:	c02000        	memw
401b9920:	5805      	l32i.n	a5, a5, 0
401b9922:	8c72      	beqz.n	a2, 0x401b992d
401b9924:	5175fb        	l32r	a5, 0x401b86f8 (0x3ffd29dd)
401b9927:	620500        	l8ui	a6, a5, 0
401b992a:	661606        	bnei	a6, 1, 0x401b9934
401b992d:	65a328        	call8	0x401e2364
401b9930:	0c02      	movi.n	a2, 0
401b9932:	1df0      	retw.n
401b9934:	8172fb        	l32r	a8, 0x401b86fc (0x3ffd29df)
401b9937:	0c17      	movi.n	a7, 1
401b9939:	91ebff        	l32r	a9, 0x401b98e8 (0x3ffd29de)
401b993c:	724800        	s8i	a7, a8, 0
401b993f:	724900        	s8i	a7, a9, 0
401b9942:	c02000        	memw
401b9945:	cc46      	bnez.n	a6, 0x401b994d
401b9947:	255dff        	call8	0x401b8f18
401b994a:	25f2ff        	call8	0x401b986c
401b994d:	81eeff        	l32r	a8, 0x401b9908 (0x40087fc4)
401b9950:	e00800        	callx8	a8
401b9953:	6135fe        	l32r	a6, 0x401b9228 (0x3ff4e0c4)
401b9956:	72aeff        	movi	a7, 0xfffffeff
401b9959:	60a620        	or	a10, a6, a6
401b995c:	817de3        	l32r	a8, 0x401b2750 (0x40082ef0)
401b995f:	e00800        	callx8	a8
401b9962:	70aa10        	and	a10, a10, a7
401b9965:	c02000        	memw
401b9968:	a906      	s32i.n	a10, a6, 0
401b996a:	259428        	call8	0x401e22ac
401b996d:	720500        	l8ui	a7, a5, 0
401b9970:	561720        	bnez	a7, 0x401b9b75
401b9973:	cd02      	mov.n	a12, a2
401b9975:	bd03      	mov.n	a11, a3
401b9977:	0c1a      	movi.n	a10, 1
401b9979:	a5d51a        	call8	0x401d46d4
401b997c:	6d0a      	mov.n	a6, a10
401b997e:	0c19      	movi.n	a9, 1
401b9980:	b62401        	bltui	a4, 2, 0x401b9985
401b9983:	9d07      	mov.n	a9, a7
401b9985:	0c08      	movi.n	a8, 0
401b9987:	907074        	extui	a7, a9, 0, 8
401b998a:	0c1a      	movi.n	a10, 1
401b998c:	9d08      	mov.n	a9, a8
401b998e:	609a93        	movnez	a9, a10, a6
401b9991:	909710        	and	a9, a7, a9
401b9994:	926134        	s32i	a9, a1, 208
401b9997:	871902        	beq	a9, a8, 0x401b999d
401b999a:	866d00        	j	0x401b9b54
401b999d:	0b84      	addi.n	a8, a4, -1
401b999f:	809a93        	movnez	a9, a10, a8
401b99a2:	926134        	s32i	a9, a1, 208
401b99a5:	c66b00        	j	0x401b9b58
