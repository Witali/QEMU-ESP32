"""Pin the actual CYD PHY fault to matching primary SDK library instructions."""
from pathlib import Path
import hashlib
import json
import struct
import subprocess

BASE=Path('C:/Work/yoRadio')
OUT=BASE/'.build/cyd-phy-analysis-20261018'
LIBROOT=Path('C:/Users/rudol/AppData/Local/Arduino15/packages/esp32/tools/esp32-libs/3.3.8')
LIB=LIBROOT/'ld/libphy.a'
DUMP=BASE/'.idf/tools-v6.1/tools/esp-clang/esp-21.1.3_20260408/esp-clang/bin/xtensa-esp32-elf-clang-objdump.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

archive=LIB.read_bytes()
assert archive.startswith(b'!<arch>\n')
at=8
member=None
while at+60<=len(archive):
    header=archive[at:at+60]
    size=int(header[48:58])
    name=header[:16].decode().strip().rstrip('/')
    if name=='phy_chip_v7.o':member=archive[at+60:at+60+size]
    at+=60+size+(size&1)
assert member and member.startswith(b'\x7fELF\x01\x01')
shoff=struct.unpack_from('<I',member,32)[0]
stride,count,names_index=struct.unpack_from('<HHH',member,46)
sections=[struct.unpack_from('<10I',member,shoff+i*stride) for i in range(count)]
names_header=sections[names_index]
names=member[names_header[4]:names_header[4]+names_header[5]]
def name_at(table,offset):return table[offset:table.index(0,offset)].decode()
section_names=[name_at(names,row[0]) for row in sections]
index=section_names.index('.text.register_chipv7_phy')
section=sections[index]
text=member[section[4]:section[4]+section[5]]
symbols=next(row for row in sections if row[1]==2)
strings=sections[symbols[6]]
strings=member[strings[4]:strings[4]+strings[5]]
symbol=None
for offset in range(symbols[4],symbols[4]+symbols[5],symbols[9]):
    row=struct.unpack_from('<IIIBBH',member,offset)
    if name_at(strings,row[0])=='register_chipv7_phy':symbol=row
assert symbol and symbol[5]==index
native=(OUT/'app-irom.bin').read_bytes()
entry=0x401b9914
linked=native[entry-0x400d0020:entry-0x400d0020+14]
library=text[symbol[1]:symbol[1]+14]
# Only the relocated l32r immediate differs in this exact entry sequence.
assert linked[:4]==library[:4] and linked[6:]==library[6:]
assert linked[0:3]==bytes.fromhex('360102')
assert linked[12:14]==bytes.fromhex('5805')
assert struct.unpack_from('<I',native,0x401b7198-0x400d0020)[0]==0x60033c00
commands={
 'linked-register-chipv7-phy.asm':[str(DUMP),'-D','-b','binary','-m','xtensa','--adjust-vma=0x400d0020','--start-address=0x401b9914','--stop-address=0x401b99a8',str(OUT/'app-irom.bin')],
 'sdk-register-chipv7-phy.asm':[str(DUMP),'-dr','-j','.text.register_chipv7_phy',str(LIB)]}
for filename,command in commands.items():
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    assert b'l32i.n' in result.stdout and b'60033c00' in result.stdout
    (OUT/filename).write_bytes(result.stdout)
versions=(LIBROOT/'versions.txt').read_text()
assert '14a0af9' in versions and 'v5.5.4 735507283d' in versions
record=dict(scope='Exact first-read identification only; not a complete PHY emulation or algorithm equivalence proof.',
    app_sha256=sha(BASE/'firmware/0.9.723/dac/app.bin'),full_flash_sha256=sha(BASE/'firmware/0.9.723/dac/full.bin'),
    library_sha256=sha(LIB),library_member='phy_chip_v7.o',member_sha256=hashlib.sha256(member).hexdigest(),
    versions=versions.splitlines()[:3],versions_sha256=sha(LIBROOT/'versions.txt'),
    objdump_sha256=sha(DUMP),function='register_chipv7_phy',linked_entry=hex(entry),fault_pc='0x401b9920',
    fault_instruction='l32i.n a5, a5, 0',fault_address='0x60033c00',
    library_entry_offset=hex(symbol[1]),library_function_size=symbol[2],
    entry_match=dict(linked=linked.hex(),library=library.hex(),ignored_offsets=[4,5],reason='l32r literal relocation'),
    apb_alias='0x3ff73c00',alias_basis='Existing esp32_soc_add_peripheral mapping: 0x60000000 corresponds to 0x3ff40000.',
    next_step='Classic ESP32 board has OpenETH but no Wi-Fi MAC/PHY device at this address. Restore a specified PHY/MAC path rather than interpreting the failure as a host-forward regression.',
    evidence={name:sha(OUT/name) for name in commands})
(OUT/'fault-identification.json').write_text(json.dumps(record,indent=2)+'\n',newline='\n')
print(json.dumps(dict(function=record['function'],entry=hex(entry),fault_pc=record['fault_pc'],fault_address=record['fault_address'],entry_match=True)))
