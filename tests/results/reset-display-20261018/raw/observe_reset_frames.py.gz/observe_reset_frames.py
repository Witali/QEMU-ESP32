"""Observe post-SNTP display latency using the unchanged frozen VM helper."""
from pathlib import Path
from types import SimpleNamespace
import datetime as dt
import hashlib
import json
import re
import sys
import time

ROOT = Path('C:/Work/yoRadio/.worktree/small-tv-runtime-supervision')
SNAP = ROOT / '.build/runtime-qemu-d64-frozen-20261018'
OUT = Path('C:/Work/yoRadio/.build/reset-frame-observation-20261018')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SNAP / 'tools'))
import small_tv_vm as vm

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs = [SNAP / 'tools/small_tv_vm.py', SNAP / 'bin/qemu-system-riscv32.exe',
          ROOT / '.build/small-tv-esp32c2/small_tv_reconstructed.elf',
          ROOT / 'firmware/development/small-tv-esp32c2-reconstructed/app.bin']
before = {str(path): sha(path) for path in inputs}
execute = vm.QMP.execute
trials = []

def guest_us(qmp):
    """Read the radio's existing low virtual microsecond counter."""
    text = execute(qmp, 'human-monitor-command', **{'command-line': 'xp /1wx 0x6004d000'})
    values = re.findall(r'0x([0-9a-fA-F]{8})\b', text)
    if len(values) != 1:
        raise ValueError('Invalid virtual clock observation')
    return int(values[0], 16)

for number in range(3):
    state = OUT / f'trial-{number}'
    rows = []

    def observe(qmp, command, **arguments):
        """Preserve the original failing capture, then sample the same live guest."""
        result = execute(qmp, command, **arguments)
        if command == 'screendump' and Path(arguments['filename']).name == 'after-reset.ppm':
            started, initial = time.monotonic(), guest_us(qmp)
            original = Path(arguments['filename'])
            pixels = vm.ppm_pixels(original)
            rows.append(dict(host_seconds=0, guest_seconds=0,
                             nonzero_bytes=sum(value != 0 for value in pixels),
                             file=original.name, sha256=sha(original)))
            while rows[-1]['nonzero_bytes'] <= 1000:
                host_seconds = time.monotonic() - started
                guest_seconds = ((guest_us(qmp) - initial) & 0xffffffff) / 1e6
                if host_seconds >= 30 or guest_seconds >= 5:
                    break
                time.sleep(.1)
                image = state / f'after-reset-observe-{len(rows):03}.ppm'
                execute(qmp, 'screendump', filename=str(image))
                rows.append(dict(host_seconds=time.monotonic() - started,
                                 guest_seconds=((guest_us(qmp) - initial) & 0xffffffff) / 1e6,
                                 nonzero_bytes=sum(value != 0 for value in vm.ppm_pixels(image)),
                                 file=image.name, sha256=sha(image)))
        return result

    vm.QMP.execute = observe
    args = SimpleNamespace(firmware='reconstructed', network='clock', seconds=30,
        yoradio=str(ROOT), rom_elf='C:/Work/yoRadio/.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf',
        app_elf=str(ROOT / '.build/small-tv-esp32c2/small_tv_reconstructed.elf'),
        qemu=str(SNAP / 'bin/qemu-system-riscv32.exe'),
        hardware_profile=str(ROOT / 'Small_TV/qemu/profiles/small-tv-c2.json'),
        http_base_port=-1, service_port=0, service_urls=None, weather_port=None,
        gdb_port=0, display='none', persistent=False, paused=False)
    result = vm.test_vm(args, state)
    trial = dict(number=number, original_checks=result['checks'], error=result['error'],
                 samples=rows, test_report_sha256=sha(state / 'test-report.json'))
    trials.append(trial)
    record = dict(tested_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        inputs_sha256=before, inputs_unchanged=all(sha(Path(path)) == value for path, value in before.items()),
        trials=trials, scope='Read-only display observations after the unchanged original reset capture; no firmware or helper fix applied.')
    (OUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(number=number, checks=result['checks'], samples=rows)), flush=True)

