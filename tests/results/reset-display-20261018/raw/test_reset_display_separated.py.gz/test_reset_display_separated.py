"""Check the fixed observer against both unchanged archived firmwares."""
from pathlib import Path
from types import SimpleNamespace
import datetime as dt
import hashlib
import json
import sys

ROOT = Path('C:/Work/yoRadio/.worktree/small-tv-runtime-supervision')
QEMU = Path('C:/Work/QEMU-ESP32/.worktree/hostfwd-backlog')
SNAP = ROOT / '.build/runtime-qemu-d64-frozen-20261018'
OUT = Path('C:/Work/yoRadio/.build/reset-display-native-separated-20261018')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(QEMU / 'tools'))
import small_tv_vm as vm

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs = [QEMU / 'tools/small_tv_vm.py', QEMU / 'tests/esp_elf_test.py',
          QEMU / 'tools/small_tv_display.py', QEMU / 'tests/small_tv_display_test.py',
          SNAP / 'bin/qemu-system-riscv32.exe', ROOT / 'Small_TV/full-flash.bin',
          ROOT / '.build/small-tv-esp32c2/small_tv_reconstructed.elf',
          ROOT / 'firmware/development/small-tv-esp32c2-reconstructed/app.bin']
before = {str(path): sha(path) for path in inputs}
trials = []
for number, variant in enumerate(('original', 'reconstructed', 'reconstructed', 'reconstructed')):
    args = SimpleNamespace(firmware=variant, network='clock', seconds=30,
        yoradio=str(ROOT), rom_elf='C:/Work/yoRadio/.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf',
        app_elf=str(ROOT / '.build/small-tv-esp32c2/small_tv_reconstructed.elf'),
        qemu=str(SNAP / 'bin/qemu-system-riscv32.exe'),
        hardware_profile=str(ROOT / 'Small_TV/qemu/profiles/small-tv-c2.json'),
        http_base_port=-1, service_port=0, service_urls=None, weather_port=None,
        gdb_port=0, display='none', persistent=False, paused=False)
    state = OUT / f'{number}-{variant}'
    result = vm.test_vm(args, state)
    trials.append(dict(number=number, firmware=variant, passed=result['passed'],
                       checks=result['checks'], error=result['error'],
                       subsystems=result['checks_by_subsystem'],
                       display=result['reset_display_observation'],
                       report_sha256=sha(state / 'test-report.json')))
    record = dict(tested_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        passed=len(trials) == 4 and all(row['passed'] for row in trials),
        inputs_sha256=before, inputs_unchanged=all(sha(Path(path)) == value for path, value in before.items()),
        trials=trials, scope='Unmodified factory and 0592 firmware boot/reset/SNTP with bounded real-panel recovery. Not full suite or H10 acceptance.')
    (OUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(number=number, variant=variant, passed=result['passed'],
                          checks=result['checks'], display=result['reset_display_observation'])), flush=True)
raise SystemExit(not record['passed'] or not record['inputs_unchanged'])
